import {initializeApp} from 'firebase/app';
import {getAuth,onAuthStateChanged,signInWithEmailAndPassword,createUserWithEmailAndPassword,sendPasswordResetEmail,signOut,GoogleAuthProvider,signInWithPopup,signInWithCredential} from 'firebase/auth';
import {initializeFirestore,persistentLocalCache,collection,doc,setDoc,getDoc,getDocs,addDoc,updateDoc,deleteDoc,deleteField,onSnapshot,query,where,serverTimestamp,Timestamp,getCountFromServer,writeBatch} from 'firebase/firestore';
import {Capacitor} from '@capacitor/core';
import {App as CapApp} from '@capacitor/app';
import {StatusBar,Style} from '@capacitor/status-bar';
import {Filesystem,Directory} from '@capacitor/filesystem';
import {FileOpener} from '@capacitor-community/file-opener';
import {FirebaseMessaging} from '@capacitor-firebase/messaging';
import {FirebaseAuthentication} from '@capacitor-firebase/authentication';
import '@fontsource/inter/latin-400.css';import '@fontsource/inter/latin-600.css';import '@fontsource/inter/latin-700.css';
import '@fontsource/hind-siliguri/bengali-400.css';import '@fontsource/hind-siliguri/bengali-600.css';import '@fontsource/hind-siliguri/bengali-700.css';
import './style.css';

const fb=initializeApp({apiKey:"AIzaSyC04mr-q_WDGmaoiM-Pab2tWYDkxAFiby4",authDomain:"notification-1e6e5.firebaseapp.com",projectId:"notification-1e6e5",storageBucket:"notification-1e6e5.firebasestorage.app",messagingSenderId:"871534419453",appId:"1:871534419453:web:aaf8e899eb4877b9dbcd94"});
const auth=getAuth(fb),db=initializeFirestore(fb,{localCache:persistentLocalCache()});
const native=Capacitor.isNativePlatform(),ADMIN=import.meta.env.VITE_APP==='admin';
const BUILD=+import.meta.env.VITE_BUILD||0,REPO=import.meta.env.VITE_REPO||'';
const NAME=ADMIN?'SCTC Admin':'SCTC Resources Hub';
const HOME=ADMIN?'send':'home';

/* ---------- storage helpers, theme ---------- */
const jget=(k,d)=>{try{return JSON.parse(localStorage.getItem(k)||d)}catch{return JSON.parse(d)}};
const jset=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch{}};
let theme=jget('theme','"light"');if(!['light','dark','auto'].includes(theme))theme='light';
const mq=window.matchMedia?matchMedia('(prefers-color-scheme: dark)'):null;
let barKind='';
const isDark=()=>theme==='dark'||(theme==='auto'&&!!mq&&mq.matches);
const applyTheme=()=>{document.documentElement.toggleAttribute('data-dark',isDark());barKind=''};
applyTheme();if(mq&&mq.addEventListener)mq.addEventListener('change',applyTheme);
let lang=jget('lang','"bn"');if(lang!=='en')lang='bn';
document.documentElement.lang=lang;

/* ---------- translations [English, Bangla] ---------- */
const D={
tag:['Learn · Connect · Stay Updated','শিখুন · যুক্ত থাকুন · আপডেট পান'],foot:['Sabuj Computer Training Center · Tomaltola, Natore','সবুজ কম্পিউটার ট্রেনিং সেন্টার · তমালতলা, নাটোর'],
signIn:['Sign in','সাইন ইন'],signUp:['Sign up','সাইন আপ'],createAcc:['Create account','অ্যাকাউন্ট খুলুন'],adminIn:['Admin sign in','অ্যাডমিন সাইন ইন'],
email:['Email','ইমেইল'],password:['Password','পাসওয়ার্ড'],fullName:['Full name','পুরো নাম'],forgot:['Forgot password?','পাসওয়ার্ড ভুলে গেছেন?'],
google:['Continue with Google','Google দিয়ে চালিয়ে যান'],or:['or','অথবা'],chooseRole:['I am a','আমি একজন'],
student:['Student','শিক্ষার্থী'],customer:['Customer','গ্রাহক'],studentHint:['Enrolled in a course','কোর্সে ভর্তি আছি'],customerHint:['Services & updates','সেবা ও আপডেট চাই'],
enterEmail:['Enter your email first','আগে ইমেইল লিখুন'],resetSent:['Password reset link sent','পাসওয়ার্ড রিসেট লিংক পাঠানো হয়েছে'],notAdmin:['This account is not an admin','এই অ্যাকাউন্টটি অ্যাডমিন নয়'],
offline:['Connect to the internet once to sign in.','সাইন ইন করতে একবার ইন্টারনেট চালু করুন।'],offBanner:['You are offline. Showing saved data.','আপনি অফলাইনে আছেন। সংরক্ষিত তথ্য দেখাচ্ছে।'],
home:['Home','হোম'],jobs:['Jobs','চাকরি'],profile:['Profile','প্রোফাইল'],send:['Send','পাঠান'],posts:['Posts','পোস্ট'],fees:['Fees','ফি'],users:['Users','ইউজার'],settings:['Settings','সেটিংস'],
hi:['Hello','হ্যালো'],unread:['unread','নতুন'],dueTitle:['Fee due','বকেয়া ফি'],dueHint:['Please pay as soon as possible','অনুগ্রহ করে দ্রুত পরিশোধ করুন'],
search:['Search…','খুঁজুন…'],all:['All','সব'],saved:['Saved','সংরক্ষিত'],bm:['Save','সংরক্ষণ'],share:['Share','শেয়ার'],copied:['Copied','কপি হয়েছে'],
noPosts:['No announcements yet','এখনো কোনো ঘোষণা নেই'],noJobs:['No job circulars right now','এখন কোনো চাকরির বিজ্ঞপ্তি নেই'],back:['Back','পিছনে'],isNew:['NEW','নতুন'],expired:['Expired','মেয়াদ শেষ'],
deadline:['Deadline','শেষ তারিখ'],
myProfile:['My profile','আমার প্রোফাইল'],completeProfile:['Complete your profile','প্রোফাইল সম্পূর্ণ করুন'],name:['Name','নাম'],mobile:['Mobile number','মোবাইল নম্বর'],village:['Village','গ্রাম'],address:['Address / Village (optional)','ঠিকানা / গ্রাম (ঐচ্ছিক)'],
photo:['Photo','ছবি'],photoHint:['Add a clear photo so we can recognise you','সহজে চেনার জন্য একটি পরিষ্কার ছবি দিন'],batch:['Batch / Course','ব্যাচ / কোর্স'],
studentNote:['Use the same mobile number and name you gave at admission, plus your village name. Tell sir whenever anything needs to change.','ভর্তির সময় যে মোবাইল নম্বর ও নাম দিয়েছিলেন সেটিই দিন, সাথে গ্রামের নাম। কিছু পরিবর্তন করতে হলে স্যারকে জানান।'],
customerNote:['Add your mobile number so we can reach you about our services and offers.','আমাদের সেবা ও অফার সম্পর্কে জানাতে আপনার মোবাইল নম্বর দিন।'],
saveForm:['Save','সেভ করুন'],signOut:['Sign out','সাইন আউট'],callUs:['Call us','কল করুন'],whatsapp:['WhatsApp','হোয়াটসঅ্যাপ'],savedOk:['Saved ✓','সেভ হয়েছে ✓'],version:['Version','ভার্সন'],
upd:['New version available. Tap to download','নতুন ভার্সন এসেছে। ডাউনলোড করতে ট্যাপ করুন'],
appearance:['Appearance','চেহারা'],theme:['Theme','থিম'],themeLight:['Light','লাইট'],themeDark:['Dark','ডার্ক'],themeAuto:['System','সিস্টেম'],language:['Language','ভাষা'],
newAnn:['New announcement','নতুন ঘোষণা'],editAnn:['Edit announcement','ঘোষণা এডিট'],sendTo:['Send to','কাকে পাঠাবেন'],type:['Type','ধরন'],
allStudents:['All students','সকল শিক্ষার্থী'],allCustomers:['All customers','সকল গ্রাহক'],everyone:['Everyone','সবাই'],batchOpt:['A batch / course…','নির্দিষ্ট ব্যাচ / কোর্স…'],peopleOpt:['Specific people…','নির্দিষ্ট ব্যক্তি…'],ppl:['people','জন'],
noBatch:['No batches yet (set one in Users tab)','কোনো ব্যাচ নেই (Users ট্যাবে সেট করুন)'],noUsers:['No users yet','এখনো কোনো ইউজার নেই'],
title:['Title','শিরোনাম'],message:['Message','বার্তা'],msgPh:['Links typed here become tappable','এখানে লেখা লিংক ক্লিকযোগ্য হবে'],
cover:['Cover image (shows big in the notification and the app)','কভার ছবি (নোটিফিকেশন ও অ্যাপে বড় করে দেখাবে)'],links:['Links (optional)','লিংক (ঐচ্ছিক)'],btnName:['Button name','বাটনের নাম'],addLink:['+ Add another link','+ আরেকটি লিংক'],
attach:['Attach PDF or images (up to 5, max 10 MB each)','PDF বা ছবি যুক্ত করুন (৫টি পর্যন্ত, প্রতিটি সর্বোচ্চ ১০ MB)'],schedule:['Schedule (optional, empty = send now)','শিডিউল (ঐচ্ছিক, খালি = এখনই)'],
pin:['Pin to top','উপরে পিন করুন'],pushOpt:['Send phone notification (works when the app is closed)','ফোনে নোটিফিকেশন পাঠান (অ্যাপ বন্ধ থাকলেও আসবে)'],
sendBtn:['Send','পাঠান'],saveChanges:['Save changes','পরিবর্তন সেভ করুন'],cancelEdit:['Cancel edit','এডিট বাতিল'],working:['Working…','অপেক্ষা করুন…'],
holFrom:['From date','শুরুর তারিখ'],holTo:['to (optional)','শেষ (ঐচ্ছিক)'],orgLbl:['Organization / company','প্রতিষ্ঠান / কোম্পানি'],dl:['Deadline / valid until','শেষ তারিখ / মেয়াদ'],
remind:['Auto-remind one day before (9:00 AM)','একদিন আগে সকাল ৯টায় অটো রিমাইন্ডার'],reminder:['Reminder','রিমাইন্ডার'],tomorrow:['Starts / ends tomorrow.','আগামীকাল।'],
errCloud:['Cloudinary is not set up (Settings)','Cloudinary সেটআপ করা নেই (সেটিংস)'],errWorker:['Worker URL missing (Settings)','Worker URL নেই (সেটিংস)'],errMax5:['Max 5 attachments','সর্বোচ্চ ৫টি ফাইল'],errBig:['is over 10 MB','১০ MB এর বেশি'],
errFuture:['Schedule time must be in the future','শিডিউলের সময় ভবিষ্যতের হতে হবে'],errSel:['Select at least one person','অন্তত একজন বাছাই করুন'],errMax40:['Select max 40 people','সর্বোচ্চ ৪০ জন বাছাই করুন'],errBatch:['Choose a batch','একটি ব্যাচ বাছাই করুন'],
sentOk:['Sent ✓','পাঠানো হয়েছে ✓'],schedOk:['Scheduled ✓','শিডিউল হয়েছে ✓'],remSet:[' + reminder set',' + রিমাইন্ডার সেট'],remLate:[' (reminder time already passed)',' (রিমাইন্ডারের সময় পার হয়ে গেছে)'],
edit:['Edit','এডিট'],resend:['Resend','আবার পাঠান'],pinBtn:['Pin','পিন'],unpin:['Unpin','আনপিন'],del:['Delete','মুছুন'],delConfirm:['Delete this announcement?','এই ঘোষণা মুছে ফেলবেন?'],
feeTitle:['Fee due reminder','বকেয়া ফি রিমাইন্ডার'],feeHint:["Set each student's due in the Users tab. {name} and {due} are filled in automatically. Max 40 at a time.",'Users ট্যাবে প্রতিটি শিক্ষার্থীর বকেয়া সেট করুন। {name} ও {due} নিজে থেকেই বসে যাবে। একসাথে সর্বোচ্চ ৪০ জন।'],
feeMsg:['Dear {name}, your course fee ৳{due} is due. Please pay as soon as possible.','প্রিয় {name}, আপনার কোর্স ফি ৳{due} বাকি আছে। অনুগ্রহ করে দ্রুত পরিশোধ করুন।'],
noDue:['No student has fee due','কারো বকেয়া নেই'],sendFee:['Send reminder to selected','নির্বাচিতদের রিমাইন্ডার পাঠান'],remSent:['Reminders sent','রিমাইন্ডার পাঠানো হয়েছে'],selStu:['Select at least one student','অন্তত একজন শিক্ষার্থী বাছাই করুন'],
stu:['students','শিক্ষার্থী'],cus:['customers','গ্রাহক'],totalDue:['total due','মোট বকেয়া'],searchUsers:['Search name, mobile, village…','নাম, মোবাইল, গ্রাম খুঁজুন…'],feeDue:['Fee due (৳)','বকেয়া ফি (৳)'],batchPh:['e.g. Morning Batch','যেমন: সকাল ব্যাচ'],
resetPw:['Reset password','পাসওয়ার্ড রিসেট'],delAcc:['Delete account','অ্যাকাউন্ট মুছুন'],resetTo:['Reset link sent to ','রিসেট লিংক পাঠানো হয়েছে: '],delAccConfirm:['Delete {n} completely? Login account, profile and messages will be removed.','{n} কে সম্পূর্ণ মুছে ফেলবেন? লগইন, প্রোফাইল ও মেসেজ সব মুছে যাবে।'],deleted:['Deleted ✓','মুছে গেছে ✓'],updated:['Updated ✓','আপডেট হয়েছে ✓'],
cloudName:['Cloudinary cloud name','Cloudinary ক্লাউড নেম'],preset:['Cloudinary unsigned upload preset','Cloudinary আনসাইনড প্রিসেট'],workerUrl:['Cloudflare Worker URL','Cloudflare Worker URL'],phone:['Institute phone / WhatsApp (with country code, e.g. 8801XXXXXXXXX)','প্রতিষ্ঠানের ফোন / হোয়াটসঅ্যাপ (দেশের কোডসহ, যেমন 8801XXXXXXXXX)'],
typesTitle:['Post types','পোস্টের ধরন'],typesHint:['These appear when sending and filtering. Set emoji, English/Bangla name, colour and kind.','পাঠানো ও ফিল্টারে এগুলো দেখাবে। ইমোজি, ইংরেজি/বাংলা নাম, রং ও ধরন ঠিক করুন।'],
addType:['+ Add type','+ নতুন ধরন'],resetTypes:['Reset to default types','ডিফল্ট ধরনে ফিরুন'],kPlain:['Normal','সাধারণ'],kDates:['Date range','তারিখ (শুরু-শেষ)'],kDeadline:['Deadline','শেষ তারিখ'],errOffline:['You are offline. Connect and try again.','আপনি অফলাইনে আছেন। ইন্টারনেট চালু করে আবার চেষ্টা করুন।'],unreadF:['Unread','নতুন'],markAll:['Mark all as read','সব পড়া হয়েছে'],
stSent:['Published','প্রকাশিত'],stSch:['Scheduled','শিডিউলড'],dup:['Duplicate','কপি'],tplT:['Quick templates','দ্রুত টেমপ্লেট'],
notifOff:['Notifications are off. Turn them on to get notices instantly.','নোটিফিকেশন বন্ধ আছে। নোটিশ সাথে সাথে পেতে চালু করুন।'],notifBtn:['Turn on','চালু করুন'],notifHow:['Open Settings → Apps → SCTC Resources Hub → Notifications','সেটিংস → অ্যাপ → SCTC Resources Hub → নোটিফিকেশন চালু করুন'],
tipsT:['Not getting notifications?','নোটিফিকেশন আসছে না?'],tipsB:['Keep internet on and allow notifications. In phone Settings set Battery to “No restrictions” and turn on Autostart (Xiaomi / Oppo / Vivo). If you were offline, missed notices arrive when you reconnect and also show in the app marked NEW.','ইন্টারনেট চালু রাখুন ও নোটিফিকেশন অনুমতি দিন। ফোনের সেটিংসে ব্যাটারি “No restrictions” করুন এবং অটোস্টার্ট চালু করুন (Xiaomi / Oppo / Vivo)। অফলাইনে থাকলে মিস হওয়া নোটিশ ইন্টারনেট এলে নোটিফিকেশনে আসবে এবং অ্যাপে “নতুন” হিসেবে দেখাবে।'],
downloading:['Downloading update','আপডেট ডাউনলোড হচ্ছে'],installing:['Opening installer…','ইনস্টলার খুলছে…'],updFail:['Update failed','আপডেট ব্যর্থ'],
googleHint:['Google sign-in failed (error 10). Install the newest APK from the GitHub release (uninstall the old one first), then try again.','Google সাইন ইন হয়নি (error 10)। আগের অ্যাপ আনইনস্টল করে GitHub Release থেকে সর্বশেষ APK ইনস্টল করে আবার চেষ্টা করুন।'],
loading:['Loading…','লোড হচ্ছে…'],signingIn:['Signing you in…','সাইন ইন হচ্ছে…'],
study:['Study','পড়াশোনা'],academy:['Academy','একাডেমি'],currentStudent:['Current student','বর্তমান শিক্ষার্থী'],oldStudent:['Old student (alumni)','প্রাক্তন শিক্ষার্থী'],
curStudents:['Current students','বর্তমান শিক্ষার্থী'],oldStudents:['Old students','প্রাক্তন শিক্ষার্থী'],course:['Course','কোর্স'],chooseCourse:['Choose your course','কোর্স বাছাই করুন'],noCourse:['Course not chosen','কোর্স বাছাই হয়নি'],
noBatch2:['Batch not assigned yet','ব্যাচ এখনো দেওয়া হয়নি'],courseOpt:['Course(s)… (current students)','কোর্স… (বর্তমান শিক্ষার্থী)'],errCourse:['Choose at least one course','অন্তত একটি কোর্স বাছাই করুন'],
courseLocked:['Course is set. Ask sir if it must change.','কোর্স ঠিক করা হয়েছে। বদলাতে স্যারকে বলুন।'],
certReady:['Your certificate has arrived! Please collect it from the center.','আপনার সার্টিফিকেট এসেছে! সেন্টার থেকে সংগ্রহ করুন।'],certGiven:['Certificate collected','সার্টিফিকেট সংগ্রহ করা হয়েছে'],
results:['Results','ফলাফল'],noResults:['No results yet','এখনো কোনো ফলাফল নেই'],marks:['Marks','নম্বর'],grade:['Grade','গ্রেড'],updatesT:['Class & exam updates','ক্লাস ও পরীক্ষার আপডেট'],
oldNote:['You are an old student. You will still get certificate, job and study-material updates.','আপনি প্রাক্তন শিক্ষার্থী। সার্টিফিকেট, চাকরি ও শিক্ষা-উপকরণের আপডেট পাবেন।'],
acStudents:['Students','শিক্ষার্থী'],acBatches:['Batches','ব্যাচ'],acResults:['Results','ফলাফল'],acFees:['Fees','ফি'],stage:['Status','অবস্থা'],stCur:['Current','বর্তমান'],stOld:['Old','প্রাক্তন'],cert:['Certificate','সার্টিফিকেট'],
certNoneO:['Not ready','আসেনি'],certReadyO:['Arrived','এসেছে'],certGivenO:['Given','দেওয়া হয়েছে'],batchSel:['Batch','ব্যাচ'],noBatchO:['— no batch —','— ব্যাচ নেই —'],noCourseO:['— no course —','— কোর্স নেই —'],unassigned:['No batch','ব্যাচ নেই'],
addBatch:['Add batch','ব্যাচ যোগ করুন'],batchName:['Batch name (e.g. Jul–Dec 2026)','ব্যাচের নাম (যেমন: জুলাই–ডিসেম্বর ২০২৬)'],start:['Start','শুরু'],end:['End','শেষ'],
completeB:['Complete → move to Old','শেষ → প্রাক্তনে পাঠান'],certB:['🎓 Certificates arrived','🎓 সার্টিফিকেট এসেছে'],moved:['students moved to Old','জন প্রাক্তনে গেছে'],
bdoneC:['Move all students of "{n}" to Old students?','"{n}" ব্যাচের সব শিক্ষার্থীকে প্রাক্তনে পাঠাবেন?'],bcertC:['Mark certificates as arrived and notify the whole batch "{n}"?','"{n}" ব্যাচের সার্টিফিকেট এসেছে বলে সবাইকে নোটিফিকেশন পাঠাবেন?'],
certTitle:['Certificates have arrived 🎓','সার্টিফিকেট এসেছে 🎓'],certBody:['Certificates for batch {n} have arrived. Please collect yours from the center.','{n} ব্যাচের সার্টিফিকেট এসেছে। অনুগ্রহ করে সেন্টার থেকে সংগ্রহ করুন।'],
bdelBlock:['Move or remove the students of this batch first','আগে এই ব্যাচের শিক্ষার্থীদের সরান'],examName:['Exam name','পরীক্ষার নাম'],totalMarks:['Total marks','মোট নম্বর'],pubRes:['Publish results & notify','ফলাফল প্রকাশ ও নোটিফাই'],
resHint:['Fill marks (grade fills automatically, you can edit). Empty rows are skipped.','নম্বর দিন (গ্রেড নিজে থেকে বসবে, চাইলে বদলাতে পারবেন)। ফাঁকা সারি বাদ যাবে।'],
errExam:['Enter exam name and total marks','পরীক্ষার নাম ও মোট নম্বর দিন'],errMarks:['Marks cannot be more than total','নম্বর মোট নম্বরের বেশি হতে পারে না'],errNoRows:['Enter marks for at least one student','অন্তত একজনের নম্বর দিন'],
resSent:['Results published','ফলাফল প্রকাশিত'],resNoBatch:['Choose a batch','একটি ব্যাচ বাছাই করুন'],gradeScale:['Grade scale (min %:grade, comma separated)','গ্রেড স্কেল (ন্যূনতম %:গ্রেড, কমা দিয়ে)'],
coursesT:['Courses','কোর্স'],coursesHint:['Courses students can choose from.','শিক্ষার্থীরা যে কোর্স বাছাই করতে পারবে।'],addCourse:['+ Add course','+ নতুন কোর্স'],
retopicFail:['Saved. Live notification groups update when the student opens the app.','সেভ হয়েছে। শিক্ষার্থী অ্যাপ খুললে নোটিফিকেশন গ্রুপ আপডেট হবে।'],
newTab:['New','নতুন'],tplTab:['Templates','টেমপ্লেট'],newTplB:['+ New template','+ নতুন টেমপ্লেট'],newTpl:['New template','নতুন টেমপ্লেট'],editTpl:['Edit template','টেমপ্লেট এডিট'],
tplName:['Template name','টেমপ্লেটের নাম'],saveTpl:['💾 Save as template','💾 টেমপ্লেট হিসেবে সেভ করুন'],saveTplBtn:['Save template','টেমপ্লেট সেভ করুন'],tplSaved:['Template saved ✓','টেমপ্লেট সেভ হয়েছে ✓'],
errTplName:['Enter a template name','টেমপ্লেটের নাম দিন'],sendNow:['Send now','এখনই পাঠান'],useTpl:['Use','ব্যবহার'],
noTpl:['No templates yet. Write a message and tap "Save as template".','এখনো কোনো টেমপ্লেট নেই। বার্তা লিখে "টেমপ্লেট হিসেবে সেভ করুন" চাপুন।'],
tplSendC:['Send "{n}" now to {a}?','"{n}" এখনই {a} কে পাঠাবেন?'],tplNoAud:['This template has no audience. Edit it and choose who to send to.','এই টেমপ্লেটে কাকে পাঠাবেন ঠিক করা নেই। এডিট করে বেছে নিন।'],
tplDelC:['Delete this template?','এই টেমপ্লেট মুছবেন?'],preview:['Notification preview','নোটিফিকেশন প্রিভিউ'],rmCover:['Remove cover image','কভার ছবি সরান'],tplSet:['Message templates','বার্তার টেমপ্লেট'],
gMorning:['Good morning','শুভ সকাল'],gAfternoon:['Good afternoon','শুভ অপরাহ্ন'],gEvening:['Good evening','শুভ সন্ধ্যা'],gNight:['Hello','হ্যালো'],
cdToday:['Today','আজ'],cdTomorrow:['Tomorrow','আগামীকাল'],cdDays:['days left','দিন বাকি'],idStudent:['STUDENT ID','শিক্ষার্থী আইডি'],idMember:['MEMBER','সদস্য'],
shareApp:['Share this app','অ্যাপটি শেয়ার করুন'],shareTxt:['Download SCTC Resources Hub for notices, results and updates.','নোটিশ, ফলাফল ও আপডেটের জন্য SCTC Resources Hub ডাউনলোড করুন।'],
typeNeed:['Keep at least one type','অন্তত একটি ধরন রাখুন'],resetConfirm:['Reset all types to default?','সব ধরন ডিফল্টে ফিরিয়ে নেবেন?']
};
const T=k=>D[k]?D[k][lang==='bn'?1:0]:k;

/* ---------- post types (editable in Settings) ---------- */
const BASE=[
 {id:'notice',e:'📢',en:'Notice',bn:'নোটিশ',c:'#0b6b2b',k:'plain'},{id:'important',e:'🚨',en:'Important',bn:'জরুরি',c:'#b42318',k:'plain'},
 {id:'exam',e:'📝',en:'Exam',bn:'পরীক্ষা',c:'#1d4ed8',k:'plain'},{id:'fee',e:'💳',en:'Fee',bn:'ফি',c:'#92400e',k:'plain'},
 {id:'holiday',e:'🏖️',en:'Holiday',bn:'ছুটি',c:'#0e7490',k:'dates'},{id:'event',e:'🎉',en:'Event',bn:'অনুষ্ঠান',c:'#c2410c',k:'plain'},
 {id:'job',e:'💼',en:'Job circular',bn:'চাকরির বিজ্ঞপ্তি',c:'#6d28d9',k:'deadline'},{id:'offer',e:'🎁',en:'Offer',bn:'অফার',c:'#be185d',k:'deadline'},
 {id:'result',e:'🏆',en:'Result',bn:'ফলাফল',c:'#a16207',k:'plain'},{id:'class',e:'🏫',en:'Class update',bn:'ক্লাস আপডেট',c:'#0f766e',k:'plain'},
 {id:'material',e:'📚',en:'Material',bn:'শিক্ষা উপকরণ',c:'#0369a1',k:'plain'},{id:'certificate',e:'🎓',en:'Certificate',bn:'সার্টিফিকেট',c:'#b45309',k:'plain'}];
const S={tab:HOME,ann:[],inbox:[],users:[],cfg:{},me:null,edit:null,open:null,f:'',un:[],roleSel:'student',complete:false,ready:{},rc:{},sy:0,pending:null,draft:null,notifOff:false,upd:null,updBusy:false,results:[],sub:'students',af:{stage:'current',course:'',batch:''},ff:'all',rs:{batch:'',exam:'',total:100},tpls:[],sendMode:'new',tplEdit:null,dr:null,pvUrl:null};
const hexOk=c=>/^#[0-9a-f]{6}$/i.test(c||'')?c:'#0b6b2b';
const getTypes=()=>Array.isArray(S.cfg.types)&&S.cfg.types.length?S.cfg.types:BASE;
const tyOf=id=>getTypes().find(x=>x.id===id)||BASE.find(x=>x.id===id)||{id,e:'📌',en:String(id),bn:String(id),c:'#0b6b2b',k:'plain'};
const tl=t=>lang==='bn'?(t.bn||t.en):(t.en||t.bn);
const tlab=id=>{const t=tyOf(id);return `${t.e} ${tl(t)}`};
const app=document.getElementById('app');
let mode='in';

const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const link=s=>esc(s).replace(/(https?:\/\/[^\s<]+)/g,'<a href="$1" target="_blank" rel="noopener">$1</a>');
const lc=()=>lang==='bn'?'bn-BD':'en-GB';
const fmt=d=>d?.toDate?d.toDate().toLocaleString(lc(),{dateStyle:'medium',timeStyle:'short'}):'';
const fday=s=>{if(!s)return'';const d=new Date(s+'T00:00:00');return isNaN(d)?esc(s):d.toLocaleDateString(lc(),{dateStyle:'medium'})};
const toLoc=d=>new Date(d-d.getTimezoneOffset()*6e4).toISOString().slice(0,16);
const err=x=>String(x.code||x.message||'Error').replace('auth/','').replace(/-/g,' ');
const toast=(m,ms=3500)=>{const e=document.createElement('div');e.className='toast';e.textContent=m;document.body.append(e);setTimeout(()=>e.remove(),ms)};
const clr=()=>{S.un.forEach(f=>f());S.un=[]};
const secs=a=>a.createdAt?.seconds??Date.now()/1000;
const sorted=L=>[...L].sort((a,b)=>(b.pinned?1:0)-(a.pinned?1:0)||secs(b)-secs(a));
let raf=0;
const soft=()=>{if(raf)return;raf=requestAnimationFrame(()=>{raf=0;if(!['send','me','set','acad'].includes(S.tab)&&!S.complete)render()})};
const seen=()=>jget('seen','[]'),mark=id=>{const s=seen();if(!s.includes(id))jset('seen',[...s,id].slice(-400))};
const saved=()=>jget('saved','[]');
const all=()=>ADMIN?S.ann:[...S.ann,...S.inbox];
const cld=(u,w,h)=>u&&u.includes('/image/upload/')?u.replace('/image/upload/',`/image/upload/c_fill,w_${w},h_${h},q_auto,f_auto/`):u;
const nimg=u=>u&&u.includes('/image/upload/')?u.replace('/image/upload/','/image/upload/c_fill,w_1000,h_500,q_auto,f_jpg/'):u;
const online=()=>{if(!navigator.onLine)throw Error(T('errOffline'))};
const incomplete=m=>!m.mobile||(m.role==='student'&&(!m.village||!m.course));
const COURSES0=[{id:'bteb',name:'BTEB'},{id:'foundation',name:'Foundation'}];
const courses=()=>Array.isArray(S.cfg.courses)&&S.cfg.courses.length?S.cfg.courses:COURSES0;
const batchList=()=>Array.isArray(S.cfg.batches)?S.cfg.batches:[];
const courseName=id=>courses().find(c=>c.id===id)?.name||'';
const batchOf=id=>batchList().find(b=>b.id===id);
const GRADES0='80:A+,70:A,60:A-,50:B,40:C,33:D,0:F';
const gradeOf=(m,t)=>{const pct=t>0?m/t*100:0;const sc=String(S.cfg.grades||GRADES0).split(',').map(x=>x.split(':')).map(([a,g])=>[parseFloat(a),String(g||'').trim()]).filter(x=>!isNaN(x[0])).sort((a,b)=>b[0]-a[0]);return (sc.find(x=>pct>=x[0])||[0,''])[1]};
const hash=s=>{let h=5381;for(const c of s)h=((h<<5)+h+c.codePointAt(0))|0;return Math.abs(h).toString(36)};
/* notification groups (FCM topics): everyone / role / current-or-old / course (current only) / batch / person */
const tpList=(m,uid)=>{const t=['all',m.role,'u_'+uid];if(m.role==='student'){t.push(m.stage==='old'?'os':'cs');if(m.batchId)t.push('b_'+m.batchId);if(m.course&&m.stage!=='old')t.push('c_'+m.course)}return t};
const topicsOf=m=>tpList(m,auth.currentUser.uid);
const tkey=m=>[m.role,m.stage||'',m.course||'',m.batchId||''].join('|');
const diffTopics=(uid,oldM,newM)=>{if(!oldM.fcm)return null;const a=tpList(oldM,uid),b=tpList(newM,uid),add=b.filter(x=>!a.includes(x)),remove=a.filter(x=>!b.includes(x));return add.length||remove.length?{tk:oldM.fcm,add,remove}:null};

/* ---------- icons ---------- */
const IC={home:'<path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',jobs:'<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/>',
user:'<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',send:'<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',list:'<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
card:'<rect x="1" y="4" width="22" height="16" rx="2"/><path d="M1 10h22"/>',users:'<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
set:'<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',search:'<circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>',
bm:'<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',share:'<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.59 13.51l6.83 3.98M15.41 6.51l-6.82 3.98"/>',
back:'<path d="M19 12H5M12 19l-7-7 7-7"/>',mail:'<rect x="2" y="4" width="20" height="16" rx="2"/><path d="M22 7l-10 6L2 7"/>',lock:'<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
phone:'<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>',
chat:'<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8z"/>',
pin:'<path d="M12 17v5M9 3h6l-1 7 3 3v2H7v-2l3-3z"/>',clock:'<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',cal:'<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
eye:'<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',link:'<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
clip:'<path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/>',out:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
cap:'<path d="M22 10L12 5 2 10l10 5 10-5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/>',
sun:'<circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/>'};
const ic=(n,s=22)=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[n]}</svg>`;
const GOOGLE='<svg width="20" height="20" viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>';

const bar=async kind=>{
  if(!native||barKind===kind)return;barKind=kind;
  try{const d=isDark();await StatusBar.setOverlaysWebView({overlay:false});
    await StatusBar.setBackgroundColor({color:kind==='green'?'#0b6b2b':d?'#0c1511':'#f4f7f5'});
    await StatusBar.setStyle({style:kind==='green'||d?Style.Dark:Style.Light})}catch{}
};
/* ---------- services ---------- */
async function up(file){
  if(!S.cfg.cloud||!S.cfg.preset)throw Error(T('errCloud'));
  const f=new FormData();f.append('file',file);f.append('upload_preset',S.cfg.preset);
  const r=await fetch(`https://api.cloudinary.com/v1_1/${S.cfg.cloud}/auto/upload`,{method:'POST',body:f});
  const j=await r.json();if(!j.secure_url)throw Error(j.error?.message||'Upload failed');return j.secure_url;
}
async function post(body){
  if(!S.cfg.workerUrl)throw Error(T('errWorker'));
  const r=await fetch(S.cfg.workerUrl,{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+await auth.currentUser.getIdToken()},body:JSON.stringify(body)});
  if(!r.ok)throw Error('Server: '+await r.text());
}
const item=(a,id)=>({topics:a.audience,title:a.title,body:(a.body||'').slice(0,240),image:nimg(a.cover||''),sub:a.sub||tlab(a.type),id});
const notify=(a,id)=>post({items:[item(a,id)]});
async function googleNative(){
  try{return await FirebaseAuthentication.signInWithGoogle({skipNativeAuth:true})}
  catch(e){
    if(/cancel/i.test(String(e?.message||e)))throw e;
    console.warn('Credential Manager failed, using classic Google sign-in',e);
    return await FirebaseAuthentication.signInWithGoogle({skipNativeAuth:true,useCredentialManager:false});
  }
}
async function checkNotif(){if(!native||ADMIN)return;try{S.notifOff=(await FirebaseMessaging.checkPermissions()).receive!=='granted'}catch{}}
async function reg(m){
  if(!native)return;
  try{
    if((await FirebaseMessaging.requestPermissions()).receive!=='granted')return;
    const now=topicsOf(m),old=jget('tp','[]');
    for(const t of now)await FirebaseMessaging.subscribeToTopic({topic:t});
    for(const t of old.filter(x=>!now.includes(x)))await FirebaseMessaging.unsubscribeFromTopic({topic:t});
    jset('tp',now);
    const {token}=await FirebaseMessaging.getToken();
    if(token&&token!==m.fcm)await updateDoc(doc(db,'users',auth.currentUser.uid),{fcm:token});
  }catch(e){console.warn(e)}
}
async function pushTopics(list){ // server-side group changes, so a transfer works even if the student never opens the app
  const m={};
  for(const it of list){
    for(const t of it.add){(m[t]=m[t]||{add:[],remove:[]}).add.push(it.tk)}
    for(const t of it.remove){(m[t]=m[t]||{add:[],remove:[]}).remove.push(it.tk)}
  }
  const ops=Object.entries(m).map(([topic,v])=>({topic,...v}));
  try{for(let i=0;i<ops.length;i+=20)await post({action:'topics',ops:ops.slice(i,i+20)})}catch(e){console.warn(e);toast(T('retopicFail'),5000)}
}
function openPost(id){
  S.sy=scrollY;S.open=id;
  if(!ADMIN&&S.user&&!seen().includes(id)&&S.ann.some(x=>x.id===id))setDoc(doc(db,'announcements',id,'reads',S.user.uid),{at:serverTimestamp()}).catch(()=>{});
  mark(id);
}
const parseUrl=u=>{const m=/^sctc:\/\/post\/([A-Za-z0-9]+)/.exec(u||'');return m?m[1]:null};
function handleOpen(id){if(!id)return;if(S.me&&!S.complete){S.tab='home';openPost(id);render();scrollTo(0,0)}else S.pending=id}
function goBack(){S.open=null;render();scrollTo(0,S.sy||0)}
if(native){
  if(!ADMIN){
    FirebaseMessaging.addListener('notificationActionPerformed',e=>handleOpen(e.notification?.data?.id));
    CapApp.addListener('appUrlOpen',e=>handleOpen(parseUrl(e.url)));
    CapApp.getLaunchUrl().then(r=>handleOpen(parseUrl(r?.url))).catch(()=>{});
    FirebaseMessaging.addListener('notificationReceived',e=>toast(e.notification?.data?.title||e.notification?.title||'🔔'));
    FirebaseMessaging.addListener('tokenReceived',e=>{if(S.user&&S.me&&e.token&&e.token!==S.me.fcm)updateDoc(doc(db,'users',S.user.uid),{fcm:e.token}).catch(()=>{})});
  }
  CapApp.addListener('backButton',()=>{
    if(!S.user||(!ADMIN&&!S.me)||S.complete)return CapApp.exitApp();
    if(S.open)return goBack();
    if(S.edit||S.tplEdit){S.edit=null;S.draft=null;if(S.tplEdit)S.sendMode='tpl';S.tplEdit=null;return render()}
    if(S.tab!==HOME){S.tab=HOME;S.f='';return render()}
    CapApp.exitApp();
  });
}
async function chk(){
  if(!REPO||!BUILD||!native)return;
  try{const r=await (await fetch(`https://api.github.com/repos/${REPO}/releases/tags/${ADMIN?'admin':'student'}`)).json();
    const n=+String(r.name).replace(/\D/g,'');const u=r.assets?.[0]?.browser_download_url;
    if(n>BUILD&&u){S.upd={url:u,n};soft()}}catch{}
}
const updBar=()=>S.upd?`<button class="upd" data-act="doupdate">⬆ ${T('upd')} (${S.upd.n})</button>`:'';
async function doUpdate(){
  if(!S.upd||S.updBusy)return;S.updBusy=true;
  const set=t=>{const e=document.querySelector('#upd .upd');if(e)e.textContent=t};
  let h;
  try{
    online();
    h=await Filesystem.addListener('progress',p=>{if(p.contentLength>0)set(`⬇ ${T('downloading')} ${Math.round(p.bytes/p.contentLength*100)}%`)});
    set(`⬇ ${T('downloading')}…`);
    const r=await Filesystem.downloadFile({url:S.upd.url,path:'sctc-update.apk',directory:Directory.Cache,progress:true});
    set(T('installing'));
    await FileOpener.open({filePath:r.path,contentType:'application/vnd.android.package-archive'});
  }catch(x){toast(T('updFail')+': '+err(x),6000)}
  finally{S.updBusy=false;if(h)h.remove();render()}
}
const netUI=()=>{const e=document.getElementById('net');if(e)e.hidden=navigator.onLine};
addEventListener('online',netUI);addEventListener('offline',netUI);

/* ---------- loading feedback ---------- */
async function run(btn,fn){ // spinner + disabled while an action is running (blocks double taps)
  if(!btn||btn.dataset.busy)return;
  btn.dataset.busy='1';const html=btn.innerHTML;btn.classList.add('busy');btn.disabled=true;btn.innerHTML='<i class="sp"></i>'+html;
  try{return await fn()}
  finally{if(btn.isConnected){btn.innerHTML=html;btn.classList.remove('busy');btn.disabled=false;delete btn.dataset.busy}}
}
const LONG=new Set(['tsend','savetpl','gg','fg','resend','ssave','bsave','bdone','bcert','bdel','rmuser','reset']);
const loadV=msg=>{app.innerHTML=`<div class="boot"><img class="a-logo pulse" src="logo.png" alt=""><div class="sp lg"></div><p>${msg||T('loading')}</p></div>`};
/* ---------- auth screens ---------- */
const langBtn=cls=>`<button class="lang ${cls||''}" data-act="lang">${lang==='bn'?'EN':'বাং'}</button>`;
function authV(){
  bar('plain');const u=mode==='up';
  app.innerHTML=`<div class="auth">${langBtn('abs')}
  <div class="a-top"><img class="a-logo" src="logo.png" alt=""><h1>${NAME}</h1><p>${T('tag')}</p></div>
  <div class="a-card">
   ${ADMIN?`<h2 class="a-h">${T('adminIn')}</h2>`:`<div class="seg"><button data-act="mode" data-m="in" class="${u?'':'on'}">${T('signIn')}</button><button data-act="mode" data-m="up" class="${u?'on':''}">${T('signUp')}</button></div>`}
   <form id="auth">
    ${u?`<div class="fld">${ic('user',18)}<input name="n" placeholder="${T('fullName')}" required autocomplete="name"></div>
    <div class="rolebox"><span>${T('chooseRole')}</span><div class="roles">
     <button type="button" data-act="role" data-r="student" class="${S.roleSel==='student'?'on':''}"><i>🎓</i><b>${T('student')}</b><small>${T('studentHint')}</small></button>
     <button type="button" data-act="role" data-r="public" class="${S.roleSel==='public'?'on':''}"><i>🛍️</i><b>${T('customer')}</b><small>${T('customerHint')}</small></button></div></div>`:''}
    <div class="fld">${ic('mail',18)}<input name="e" type="email" placeholder="${T('email')}" required autocomplete="email" inputmode="email"></div>
    <div class="fld">${ic('lock',18)}<input name="p" type="password" placeholder="${T('password')}" minlength="6" required autocomplete="${u?'new-password':'current-password'}"><button type="button" class="eye" data-act="eye">${ic('eye',18)}</button></div>
    ${u?'':`<button type="button" class="lnk r" data-act="fg">${T('forgot')}</button>`}
    <button class="btn">${u?T('createAcc'):T('signIn')}</button>
   </form>
   <div class="or"><span>${T('or')}</span></div>
   <button class="gbtn" data-act="gg">${GOOGLE}<span>${T('google')}</span></button>
  </div><p class="a-foot">${T('foot')}</p></div>`;
}
const avatar=(m,sz)=>m.photo?`<img class="av ${sz||''}" src="${esc(cld(m.photo,240,240))}" alt="">`:`<div class="av ph ${sz||''}">${esc((m.name||'?').trim().charAt(0).toUpperCase())}</div>`;
const crsField=(m,stu)=>{const lock=!!m.course;return `<div class="crs" ${stu?'':'hidden'}><label>${T('course')}</label><select name="crs" ${stu?'required':''} ${lock?'disabled':''}><option value="">${T('chooseCourse')}</option>${courses().map(c=>`<option value="${esc(c.id)}" ${m.course===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select>${lock?`<small class="hint">${T('courseLocked')}</small>`:''}</div>`};
const profF=(m,create)=>{
  const stu=create?true:m.role==='student';
  return `<form id="prof" class="pf">${avatar(m)}<h2>${create?T('completeProfile'):T('myProfile')}</h2>
  ${create?'':`<div class="rolepill">${stu?'🎓 '+T('student'):'🛍️ '+T('customer')}${m.course?' · '+esc(courseName(m.course)):''}${batchOf(m.batchId)?' · '+esc(batchOf(m.batchId).name):''}</div>`}
  <label>${T('name')}</label><input name="n" required value="${esc(m.name)}" autocomplete="name">
  <label>${T('mobile')}</label><input name="m" type="tel" inputmode="tel" required value="${esc(m.mobile)}" autocomplete="tel">
  ${create?`<label>${T('chooseRole')}</label><select name="r"><option value="student">${T('student')}</option><option value="public">${T('customer')}</option></select>`:''}
  <label class="vl">${stu?T('village'):T('address')}</label><input name="v" ${stu?'required':''} value="${esc(m.village)}">
  ${crsField(m,stu)}
  <label>${T('photo')}</label><input name="ph" type="file" accept="image/*"><small class="hint">${T('photoHint')}</small>
  <p class="note n-stu" ${stu?'':'hidden'}>ℹ️ ${T('studentNote')}</p><p class="note n-cus" ${stu?'hidden':''}>ℹ️ ${T('customerNote')}</p>
  <button class="btn">${T('saveForm')}</button></form>`;
};
const contact=()=>S.cfg.phone?`<div class="two"><a class="btn ghost" href="tel:${esc(S.cfg.phone)}">${ic('phone',18)} ${T('callUs')}</a><a class="btn ghost" href="https://wa.me/${esc(String(S.cfg.phone).replace(/\D/g,''))}" target="_blank" rel="noopener">${ic('chat',18)} ${T('whatsapp')}</a></div>`:'';
const outBtn=()=>`<button class="btn out" data-act="logout">${ic('out',18)} ${T('signOut')}</button>`;
const themeBox=()=>`<div class="sec"><h3 class="sh">${ic('sun',20)} ${T('appearance')}</h3><label>${T('theme')}</label>
  <div class="seg3">${[['light','themeLight'],['dark','themeDark'],['auto','themeAuto']].map(([v,k])=>`<button data-act="theme" data-v="${v}" class="${theme===v?'on':''}">${T(k)}</button>`).join('')}</div>
  <label>${T('language')}</label><div class="seg3 two">${[['bn','বাংলা'],['en','English']].map(([v,n])=>`<button data-act="setlang" data-v="${v}" class="${lang===v?'on':''}">${n}</button>`).join('')}</div></div>`;
const verLine=()=>`<p class="ver">${NAME} · ${T('version')} ${BUILD||'dev'}</p>`;
function profileV(){ // first-time Google user: no profile yet
  bar('plain');
  getDoc(doc(db,'settings','main')).then(s=>{S.cfg=s.data()||{}}).catch(()=>{});
  app.innerHTML=`<div class="auth plain">${langBtn('abs')}<div class="a-card flat">${profF({name:S.user.displayName||''},true)}${outBtn()}</div></div>`;
}
function completeV(){
  bar('plain');
  app.innerHTML=`<div class="auth plain">${langBtn('abs')}<div class="a-card flat">${profF(S.me,false).replace(T('myProfile'),T('completeProfile'))}${outBtn()}</div></div>`;
}

/* ---------- main views ---------- */
const chip=a=>{const t=tyOf(a.type);return `<span class="chip" style="--c:${hexOk(t.c)}">${t.e} ${esc(tl(t))}</span>`};
const cdChip=a=>{const d=a.deadline||a.from;if(!d)return'';const n=Math.round((new Date(d+'T00:00:00')-new Date(new Date().toDateString()))/864e5);if(n<0||n>60)return'';return `<span class="chip cd ${n<=1?'u':''}">⏳ ${n===0?T('cdToday'):n===1?T('cdTomorrow'):n+' '+T('cdDays')}</span>`};
const isExp=a=>a.deadline&&new Date(a.deadline+'T23:59:59')<new Date();
const rcBadge=a=>ADMIN&&a.status!=='scheduled'?`<span class="rc" data-rc="${a.id}">${ic('eye',13)} <b>${S.rc[a.id]??'–'}</b></span>`:'';
const badges=a=>`${a.status==='scheduled'?`<span class="chip sch">${ic('clock',12)} ${fmt(a.sendAt)}</span>`:''}${!ADMIN&&!seen().includes(a.id)?`<span class="chip nw">${T('isNew')}</span>`:''}${isExp(a)?`<span class="chip ex">${T('expired')}</span>`:cdChip(a)}${a.pinned?`<span class="pinb">${ic('pin',14)}</span>`:''}`;
const meta=a=>[a.org?`${ic('jobs',14)} ${esc(a.org)}`:'',a.deadline?`${ic('cal',14)} ${T('deadline')}: ${fday(a.deadline)}`:'',a.from?`${ic('cal',14)} ${fday(a.from)}${a.to?' → '+fday(a.to):''}`:''].filter(Boolean).map(x=>`<span>${x}</span>`).join('');
const audLbl=a=>a.al?esc(a.al):(({student:T('allStudents'),public:T('allCustomers'),all:T('everyone')})[a.audience?.[0]]||`${a.audience?.length||0} ${T('ppl')}`);
const card=a=>`<article class="card ${ADMIN?'':'tap'}" data-id="${a.id}" data-open="1" data-item>
  ${a.cover?`<div class="cv"><img src="${esc(cld(a.cover,900,450))}" loading="lazy" decoding="async" alt=""></div>`:''}
  <div class="cb"><div class="r1">${chip(a)}${badges(a)}</div><h3>${esc(a.title)}</h3><p class="ex">${esc((a.body||'').slice(0,150))}</p>
  ${meta(a)?`<div class="meta">${meta(a)}</div>`:''}
  <div class="foot"><small>${fmt(a.createdAt)}${ADMIN?' · '+audLbl(a):''}</small>${ADMIN?rcBadge(a):`<button class="ib ${saved().includes(a.id)?'on':''}" data-act="save" aria-label="${T('bm')}">${ic('bm',18)}</button>`}</div>
  ${ADMIN?`<div class="row"><button data-act="edit">${T('edit')}</button><button data-act="dup">${T('dup')}</button><button data-act="resend">${T('resend')}</button><button data-act="pin">${a.pinned?T('unpin'):T('pinBtn')}</button><button data-act="del" class="dng">${T('del')}</button></div>`:''}</div></article>`;
const detailV=a=>`<button class="back" data-act="back">${ic('back',18)} ${T('back')}</button><article class="card det">
  ${a.cover?`<div class="cv big"><img src="${esc(cld(a.cover,1000,560))}" decoding="async" alt=""></div>`:''}
  <div class="cb"><div class="r1">${chip(a)}${badges(a)}</div><h2>${esc(a.title)}</h2>${meta(a)?`<div class="meta">${meta(a)}</div>`:''}
  <p class="body">${link(a.body)}</p>
  ${(a.links||[]).map(l=>`<a class="btn" href="${esc(l.u)}" target="_blank" rel="noopener">${ic('link',18)} ${esc(l.t)}</a>`).join('')}
  ${(a.files||[]).map(x=>`<a class="fl" href="${esc(x.u)}" target="_blank" rel="noopener">${ic('clip',18)} ${esc(x.n)}</a>`).join('')}
  <div class="foot"><small>${fmt(a.createdAt)}</small><span><button class="ib ${saved().includes(a.id)?'on':''}" data-id="${a.id}" data-act="save">${ic('bm',18)}</button><button class="ib" data-id="${a.id}" data-act="share">${ic('share',18)}</button></span></div></div></article>`;
const unread=()=>all().filter(a=>a.status!=='scheduled'&&!seen().includes(a.id)).length;
const greet=()=>{const h=new Date().getHours();return h<5||h>=21?'gNight':h<12?'gMorning':h<17?'gAfternoon':'gEvening'};
const dueCard=()=>S.me.role==='student'&&S.me.due>0?`<div class="due"><div><b>${T('dueTitle')}: ৳${esc(S.me.due)}</b><small>${T('dueHint')}</small></div>${S.cfg.phone?`<a class="mini" href="tel:${esc(S.cfg.phone)}">${ic('phone',18)}</a>`:''}</div>`:'';
const hero=()=>{const n=unread();
  return `<section class="hero">${avatar(S.me,'sm')}<div class="hn"><small>${T(greet())} 👋</small><h2>${esc(S.me.name)}</h2></div><div class="stat"><b>${n}</b><small>${T('unread')}</small></div></section>
  ${dueCard()}`};
const searchBox=(id,ph)=>`<div class="sb">${ic('search',18)}<input class="q" data-q="${id}" placeholder="${ph||T('search')}"></div>`;
const skel=()=>Array(3).fill('<div class="card sk"><div class="cv"></div><div class="cb"><i></i><i class="w"></i><i class="s"></i></div></div>').join('');
function feedV(jobsOnly){
  const a=S.open&&all().find(x=>x.id===S.open);if(a&&!ADMIN)return detailV(a);
  let l=sorted(all()).filter(x=>ADMIN||x.status!=='scheduled');
  if(jobsOnly)l=l.filter(x=>x.type==='job');else if(S.f==='__saved')l=l.filter(x=>saved().includes(x.id));else if(S.f==='__unread')l=l.filter(x=>!seen().includes(x.id));else if(S.f)l=l.filter(x=>x.type===S.f);
  const chips=jobsOnly?'':`<div class="chips">${[['',T('all')],...(ADMIN?[]:[['__unread','● '+T('unreadF')],['__saved','★ '+T('saved')]]),...getTypes().map(t=>[t.id,`${t.e} ${tl(t)}`])].map(([k,n])=>`<button data-act="flt" data-k="${esc(k)}" class="${S.f===k?'on':''}">${esc(n)}</button>`).join('')}</div>`;
  const body=!S.ready.ann?skel():l.length?l.map(card).join(''):`<div class="empty">${ic(jobsOnly?'jobs':'bell',40)}<p>${jobsOnly?T('noJobs'):T('noPosts')}</p></div>`;
  const n=ADMIN||jobsOnly?0:unread();
  const warn=!ADMIN&&!jobsOnly&&S.notifOff?`<div class="note warn"><span>🔕 ${T('notifOff')}</span><button data-act="notifreq">${T('notifBtn')}</button></div>`:'';
  const stats=ADMIN&&!jobsOnly?(()=>{const sent=S.ann.filter(a=>a.status!=='scheduled').length;return `<div class="stats"><div><b>${sent}</b><small>${T('stSent')}</small></div><div><b>${S.ann.length-sent}</b><small>${T('stSch')}</small></div><div><b>${S.users.length}</b><small>${T('users')}</small></div></div>`})():'';
  return `${ADMIN||jobsOnly?'':hero()}${warn}${stats}${searchBox('feed')}${n?`<button class="lnk readall" data-act="readall">✓ ${T('markAll')} (${n})</button>`:''}${chips}<div id="feed">${body}</div>`;
}
const linkRow=(l={})=>`<div class="two lk"><input placeholder="${T('btnName')}" value="${esc(l.t)}"><input placeholder="https://…" value="${esc(l.u)}"></div>`;
/* ---------- saved templates ---------- */
const APPN='SCTC Resources Hub';
const tplList=()=>S.tpls||[];
const saveTpls=async l=>{online();await setDoc(doc(db,'settings','templates'),{list:l});S.tpls=l};
const sendTabs=()=>S.edit||S.tplEdit?'':`<div class="seg3 two">${[['new',T('newTab')],['tpl',`⭐ ${T('tplTab')} (${tplList().length})`]].map(([k,n])=>`<button data-act="smode" data-k="${k}" class="${S.sendMode===k?'on':''}">${n}</button>`).join('')}</div>`;
const previewBox=()=>`<div class="npvw"><small>${T('preview')}</small><div id="npv" class="npv"></div></div>`;
const tplCards=()=>tplList().map(t=>`<div class="card tpl" data-id="${esc(t.id)}">${t.cover?`<div class="cv"><img src="${esc(cld(t.cover,600,300))}" loading="lazy" alt=""></div>`:''}<div class="cb"><div class="r1">${chip(t)}</div><h3>⭐ ${esc(t.name)}</h3><p class="ex">${esc(t.title)} — ${esc(t.body)}</p>${t.al?`<small>→ ${esc(t.al)}</small>`:''}
  <div class="row"><button class="primary" data-act="tsend">⚡ ${T('sendNow')}</button><button data-act="tuse">${T('useTpl')}</button><button data-act="tedit">${T('edit')}</button><button data-act="tdel" class="dng">${T('del')}</button></div></div></div>`).join('')||`<div class="empty">${ic('list',40)}<p>${T('noTpl')}</p></div>`;
const tplV=()=>`${sendTabs()}<button class="btn ghost sm" data-act="tnew">${T('newTplB')}</button>${tplCards()}`;
function updPreview(f){
  const e=document.getElementById('npv');if(!e)return;
  const base=S.edit||S.draft||{},file=f.cvr.files[0];
  if(S.pvUrl){URL.revokeObjectURL(S.pvUrl);S.pvUrl=null}
  let src='';if(file){S.pvUrl=URL.createObjectURL(file);src=S.pvUrl}else if(!f.rmcover?.checked&&base.cover)src=cld(base.cover,600,300);
  const t=tyOf(f.typ.value);
  e.innerHTML=`<img class="nl" src="logo.png" alt=""><div class="nb"><small>${APPN} · ${t.e} ${esc(tl(t))}</small><b>${esc(f.ttl.value||T('title'))}</b><p>${esc((f.msg.value||T('message')).slice(0,160))}</p>${src?`<img class="nc" src="${esc(src)}" alt="">`:''}</div>`;
}
function formTouched(f){if(!S.edit&&!S.draft&&!S.tplEdit)S.dr={ttl:f.ttl.value,msg:f.msg.value,typ:f.typ.value,aud:f.aud.value};updPreview(f)}
async function collect(f,base){ // reads the compose form into a post object (uploads new files)
  const cv=f.cvr.files[0],fl=[...f.att.files];
  if(fl.length>5)throw Error(T('errMax5'));const big=fl.find(x=>x.size>1e7);if(big)throw Error(big.name+' '+T('errBig'));
  const ty=f.typ.value,k=tyOf(ty).k||'plain',hol=k==='dates',jb=k==='deadline';
  const keep=(base.files||[]).filter((_,i)=>f.querySelector(`.kf[value="${i}"]`)?.checked);
  const files=[...keep,...await Promise.all(fl.map(async x=>({n:x.name,u:await up(x)})))];
  if(files.length>5)throw Error(T('errMax5'));
  return {title:f.ttl.value.trim(),body:f.msg.value.trim(),type:ty,sub:tlab(ty),...audOf(f),pinned:f.pn.checked,push:f.nt?f.nt.checked:true,
    cover:cv?await up(cv):(f.rmcover?.checked?'':base.cover||''),from:hol?f.hf.value:'',to:hol?f.ht.value:'',org:jb?f.og.value.trim():'',deadline:jb?f.dl.value:'',
    links:[...f.querySelectorAll('.lk')].map(r=>({t:r.children[0].value.trim(),u:r.children[1].value.trim()})).filter(l=>l.t&&/^https?:\/\//i.test(l.u)),files};
}
async function doTplSave(f,keep){
  const name=(f.tname?.value||'').trim();if(!name)throw Error(T('errTplName'));
  const a=await collect(f,S.edit||S.draft||{});
  const id=S.tplEdit&&S.tplEdit!=='new'?S.tplEdit:'t'+Date.now().toString(36);
  const t={id,name,type:a.type,title:a.title,body:a.body,cover:a.cover||'',links:a.links,files:a.files,audience:a.audience,al:a.al||'',pinned:!!a.pinned,org:a.org||''};
  const l=tplList();await saveTpls(l.some(x=>x.id===id)?l.map(x=>x.id===id?t:x):[...l,t]);
  toast(T('tplSaved'));
  if(!keep){S.tplEdit=null;S.draft=null;S.dr=null;S.sendMode='tpl';render()}
}
const TPL=[
 {ty:'class',en:['Class cancelled today','Today\u2019s class is cancelled. We will inform you about the next class soon.'],bn:['আজ ক্লাস বন্ধ','আজকের ক্লাস বন্ধ থাকবে। পরবর্তী ক্লাসের তারিখ শীঘ্রই জানানো হবে।']},
 {ty:'exam',en:['Exam notice','The exam will be held on [date] at [time]. Please come on time with your ID card.'],bn:['পরীক্ষার নোটিশ','পরীক্ষা [তারিখ] তারিখে [সময়] এ অনুষ্ঠিত হবে। অনুগ্রহ করে আইডি কার্ডসহ সময়মতো উপস্থিত হবেন।']},
 {ty:'holiday',en:['Holiday notice','Our center will remain closed on the dates below. Classes resume afterwards.'],bn:['ছুটির নোটিশ','নিচের তারিখগুলোতে আমাদের সেন্টার বন্ধ থাকবে। এরপর যথারীতি ক্লাস চলবে।']},
 {ty:'fee',en:['Fee reminder','Please pay your due course fee as soon as possible. Thank you.'],bn:['ফি রিমাইন্ডার','অনুগ্রহ করে বকেয়া কোর্স ফি দ্রুত পরিশোধ করুন। ধন্যবাদ।']},
 {ty:'result',en:['Result published','The result has been published. Please check with your instructor.'],bn:['ফলাফল প্রকাশিত','ফলাফল প্রকাশ করা হয়েছে। বিস্তারিত জানতে শিক্ষকের সাথে যোগাযোগ করুন।']}];
const composeV=()=>{
  const a=S.edit||S.draft||{},tpe=!!S.tplEdit,canSch=!tpe&&(!S.edit||a.status==='scheduled'),nt=!S.edit||a.status==='scheduled';
  const tys=getTypes().some(t=>t.id===a.type)||!a.type?getTypes():[...getTypes(),tyOf(a.type)];
  return `${sendTabs()}${previewBox()}<form id="send" class="sec"><h3 class="sh">${ic('send',20)} ${tpe?(S.tplEdit==='new'?T('newTpl'):T('editTpl')):S.edit?T('editAnn'):T('newAnn')}</h3>
  <div class="two"><div><label>${T('sendTo')}</label><select name="aud"><option value="student">${T('allStudents')}</option><option value="cs">${T('curStudents')}</option><option value="os">${T('oldStudents')}</option><option value="public">${T('allCustomers')}</option><option value="all">${T('everyone')}</option><option value="course">${T('courseOpt')}</option><option value="batch">${T('batchOpt')}</option><option value="users">${T('peopleOpt')}</option></select></div>
  <div><label>${T('type')}</label><select name="typ">${tys.map(t=>`<option value="${esc(t.id)}">${t.e} ${esc(tl(t))}</option>`).join('')}</select></div></div>
  <div id="cx" class="ul" hidden>${courses().map(c=>`<label class="ck"><input type="checkbox" class="cc" value="${esc(c.id)}" ${a.audience?.includes('c_'+c.id)?'checked':''}> ${esc(c.name)}</label>`).join('')}</div>
  <div id="bx" class="ul" hidden>${batchList().map(b=>`<label class="ck"><input type="checkbox" class="bc2" value="${esc(b.id)}" ${a.audience?.includes('b_'+b.id)?'checked':''}> ${esc(b.name)}${b.course?' · '+esc(courseName(b.course)):''}${b.done?' ('+T('stOld')+')':''}</label>`).join('')||T('noBatch')}</div>
  <div id="pw" hidden>${searchBox('ul')}<div id="ul" class="ul">${S.users.map(u=>`<label class="ck pk" data-item><input type="checkbox" class="uc" value="${esc(u.id)}" ${a.audience?.includes('u_'+u.id)?'checked':''}>${avatar(u,'xs')}<span>${esc(u.name)}<small>${u.role==='student'?esc(courseName(u.course)||T('student'))+(batchOf(u.batchId)?' · '+esc(batchOf(u.batchId).name):'')+(u.stage==='old'?' · '+T('stOld'):''):T('customer')} · ${esc(u.village)}</small></span></label>`).join('')||T('noUsers')}</div></div>
  <div id="hol" hidden><div class="two"><div><label>${T('holFrom')}</label><input type="date" name="hf" value="${esc(a.from)}"></div><div><label>${T('holTo')}</label><input type="date" name="ht" value="${esc(a.to)}"></div></div></div>
  <div id="jb" hidden><label>${T('orgLbl')}</label><input name="og" value="${esc(a.org)}"><label>${T('dl')}</label><input type="date" name="dl" value="${esc(a.deadline)}"></div>
  ${S.edit||tpe?'':`<label class="ck" id="rmb" hidden><input type="checkbox" name="rm" checked> ${T('remind')}</label>`}
  ${S.edit||tpe?'':`<label>${T('tplT')}</label><div class="chips">${tplList().map(t=>`<button type="button" data-act="tuse" data-id="${esc(t.id)}">⭐ ${esc(t.name)}</button>`).join('')}${TPL.map((t,i)=>`<button type="button" data-act="tpl" data-i="${i}">${tyOf(t.ty).e} ${esc(t[lang][0])}</button>`).join('')}</div>`}
  ${tpe?`<label>${T('tplName')}</label><input name="tname" required maxlength="60" value="${esc(a.name)}">`:''}
  <label>${T('title')}</label><input name="ttl" required maxlength="100" value="${esc(a.title)}">
  <label>${T('message')}</label><textarea name="msg" rows="6" placeholder="${T('msgPh')}">${esc(a.body)}</textarea>
  <label>${T('cover')}</label><input name="cvr" type="file" accept="image/*">
  ${a.cover?`<div class="cvkeep"><img src="${esc(cld(a.cover,200,120))}" alt=""><label class="ck"><input type="checkbox" name="rmcover"> ${T('rmCover')}</label></div>`:''}
  <label>${ic('link',14)} ${T('links')}</label><div id="lks">${(a.links?.length?a.links:[{}]).map(linkRow).join('')}</div><button type="button" class="btn ghost sm" data-act="addlink">${T('addLink')}</button>
  <label>${T('attach')}</label><input name="att" type="file" multiple accept="application/pdf,image/*">
  ${(a.files||[]).map((x,i)=>`<label class="ck"><input type="checkbox" class="kf" value="${i}" checked> 📎 ${esc(x.n)}</label>`).join('')}
  ${canSch?`<label>${ic('clock',14)} ${T('schedule')}</label><input type="datetime-local" name="sch" value="${a.sendAt?.toDate?toLoc(a.sendAt.toDate()):''}">`:''}
  <label class="ck"><input type="checkbox" name="pn" ${a.pinned?'checked':''}> ${T('pin')}</label>
  ${tpe?'':`<label class="ck"><input type="checkbox" name="nt" ${nt?'checked':''}> ${T('pushOpt')}</label>`}
  <button class="btn send">${tpe?T('saveTplBtn'):S.edit?T('saveChanges'):T('sendBtn')}</button>${S.edit||tpe?`<button type="button" class="btn ghost" data-act="cancel">${T('cancelEdit')}</button>`:''}
  ${tpe?'':`<details class="tsave"><summary>${T('saveTpl')}</summary><input name="tname" placeholder="${T('tplName')}" maxlength="60"><button type="button" class="btn ghost sm" data-act="savetpl">${T('saveTplBtn')}</button></details>`}</form>`;
};
const stChip=m=>`<span class="chip ${m.stage==='old'?'ex':''}">${m.stage==='old'?T('stOld'):T('stCur')}</span>`;
const opt=(v,t,sel)=>`<option value="${esc(v)}" ${sel?'selected':''}>${esc(t)}</option>`;
const feeV=()=>{
  let l=S.users.filter(u=>u.role==='student'&&u.due>0);
  if(S.ff==='current')l=l.filter(u=>u.stage!=='old');else if(S.ff==='old')l=l.filter(u=>u.stage==='old');
  return `<form id="fee" class="sec"><h3 class="sh">${ic('card',20)} ${T('feeTitle')}</h3><small class="hint">${T('feeHint')}</small>
  <div class="chips">${[['all',T('all')],['current',T('stCur')],['old',T('stOld')]].map(([k,n])=>`<button type="button" data-act="ff" data-k="${k}" class="${S.ff===k?'on':''}">${n}</button>`).join('')}</div>
  <label>${T('message')}</label><textarea name="msg" rows="4">${esc(T('feeMsg'))}</textarea>
  ${searchBox('fl')}<div class="ul tall" id="fl">${l.map(u=>`<label class="ck pk" data-item><input type="checkbox" class="fc" value="${esc(u.id)}" checked>${avatar(u,'xs')}<span>${esc(u.name)}<small>${esc(courseName(u.course))} · ${esc(u.village)} · ৳${esc(u.due)} · ${u.stage==='old'?T('stOld'):T('stCur')}</small></span></label>`).join('')||T('noDue')}</div>
  <button class="btn send">${T('sendFee')}</button></form>`;
};
const usersV=()=>{
  const st=S.users.filter(u=>u.role==='student').length;
  return `<div class="stats"><div><b>${st}</b><small>${T('stu')}</small></div><div><b>${S.users.length-st}</b><small>${T('cus')}</small></div><div><b>${S.users.length}</b><small>${T('users')}</small></div></div>
  ${searchBox('ulist',T('searchUsers'))}
  <div id="ulist">${S.users.map(u=>`<div class="card cb ucard" data-uid="${esc(u.id)}" data-item><div class="uh">${avatar(u,'xs')}<div><b>${esc(u.name)}</b><small>${esc(u.email)}</small></div></div>
  <div class="meta"><span>${ic('phone',14)} ${esc(u.mobile)||'—'}</span><span>${ic('home',14)} ${esc(u.village)||'—'}</span></div>
  <select data-role="1"><option value="student" ${u.role==='student'?'selected':''}>${T('student')}</option><option value="public" ${u.role==='public'?'selected':''}>${T('customer')}</option></select>
  <div class="row"><button data-act="reset">${T('resetPw')}</button><button data-act="rmuser" class="dng">${T('delAcc')}</button></div></div>`).join('')||`<div class="empty">${ic('users',40)}<p>${T('noUsers')}</p></div>`}</div>`;
};
/* ---------- academy (admin) ---------- */
const stuCard=u=>`<div class="card cb ucard" data-uid="${esc(u.id)}" data-item><div class="uh">${avatar(u,'xs')}<div><b>${esc(u.name)}</b><small>${esc(u.mobile)||'—'} · ${esc(u.village)||'—'}</small></div></div>
 <div class="r1" style="margin:8px 0">${stChip(u)}${u.course?`<span class="chip">${esc(courseName(u.course))}</span>`:''}${u.cert==='ready'?'<span class="chip nw">🎓</span>':''}</div>
 <div class="two"><div><label>${T('course')}</label><select class="f-course">${opt('',T('noCourseO'),!u.course)}${courses().map(c=>opt(c.id,c.name,u.course===c.id)).join('')}</select></div>
 <div><label>${T('batchSel')}</label><select class="f-batch">${opt('',T('noBatchO'),!u.batchId)}${batchList().map(b=>opt(b.id,b.name,u.batchId===b.id)).join('')}</select></div></div>
 <div class="two"><div><label>${T('stage')}</label><select class="f-stage">${opt('current',T('stCur'),u.stage!=='old')}${opt('old',T('stOld'),u.stage==='old')}</select></div>
 <div><label>${T('cert')}</label><select class="f-cert">${opt('none',T('certNoneO'),!u.cert||u.cert==='none')}${opt('ready',T('certReadyO'),u.cert==='ready')}${opt('given',T('certGivenO'),u.cert==='given')}</select></div></div>
 <label>${T('feeDue')}</label><input type="number" min="0" class="f-due" value="${+u.due||0}">
 <button class="btn ghost sm" data-act="ssave">${T('saveForm')}</button></div>`;
function acStudents(){
  const f=S.af;let l=S.users.filter(u=>u.role==='student');
  if(f.stage==='current')l=l.filter(u=>u.stage!=='old');else if(f.stage==='old')l=l.filter(u=>u.stage==='old');
  if(f.course)l=l.filter(u=>u.course===f.course);
  if(f.batch==='__none')l=l.filter(u=>!u.batchId);else if(f.batch)l=l.filter(u=>u.batchId===f.batch);
  const due=l.reduce((t,u)=>t+(+u.due||0),0);
  return `<div class="chips">${[['current',T('stCur')],['old',T('stOld')],['all',T('all')]].map(([k,n])=>`<button data-act="afstage" data-k="${k}" class="${f.stage===k?'on':''}">${n}</button>`).join('')}</div>
  <div class="two"><select data-af="course"><option value="">${T('course')}: ${T('all')}</option>${courses().map(c=>opt(c.id,c.name,f.course===c.id)).join('')}</select>
  <select data-af="batch"><option value="">${T('batchSel')}: ${T('all')}</option>${opt('__none',T('unassigned'),f.batch==='__none')}${batchList().map(b=>opt(b.id,b.name,f.batch===b.id)).join('')}</select></div>
  <div class="stats"><div><b>${l.length}</b><small>${T('stu')}</small></div><div><b>৳${due}</b><small>${T('totalDue')}</small></div><div><b>${l.filter(u=>u.cert==='ready').length}</b><small>${T('certReadyO')}</small></div></div>
  ${searchBox('slist',T('searchUsers'))}<div id="slist">${l.map(stuCard).join('')||`<div class="empty">${ic('users',40)}<p>${T('noUsers')}</p></div>`}</div>`;
}
function acBatches(){
  const form=`<form id="newbatch" class="sec"><h3 class="sh">${ic('cap',20)} ${T('addBatch')}</h3><label>${T('batchName')}</label><input name="bn" required maxlength="60">
   <label>${T('course')}</label><select name="bc">${courses().map(c=>opt(c.id,c.name)).join('')}</select>
   <div class="two"><div><label>${T('start')}</label><input type="date" name="bs"></div><div><label>${T('end')}</label><input type="date" name="be"></div></div><button class="btn">${T('addBatch')}</button></form>`;
  return form+batchList().map(b=>{const st=S.users.filter(u=>u.role==='student'&&u.batchId===b.id),cur=st.filter(u=>u.stage!=='old').length;
   return `<div class="card cb" data-bid="${esc(b.id)}"><div class="r1"><b>${esc(b.name)}</b><span class="chip ${b.done?'ex':''}">${b.done?T('stOld'):T('stCur')}</span></div>
   <small>${esc(courseName(b.course))} · ${cur} ${T('stCur')} · ${st.length-cur} ${T('stOld')}</small>
   <div class="two" style="margin-top:8px"><input class="bn" value="${esc(b.name)}"><select class="bc">${courses().map(c=>opt(c.id,c.name,b.course===c.id)).join('')}</select></div>
   <div class="two"><input type="date" class="bs" value="${esc(b.start)}"><input type="date" class="be" value="${esc(b.end)}"></div>
   <div class="row"><button data-act="bsave">${T('saveForm')}</button><button data-act="bdone">${T('completeB')}</button><button data-act="bcert">${T('certB')}</button><button data-act="bdel" class="dng">${T('del')}</button></div></div>`}).join('');
}
function acResults(){
  const r=S.rs,st=r.batch?S.users.filter(u=>u.role==='student'&&u.batchId===r.batch):[];
  return `<form id="results" class="sec"><h3 class="sh">${ic('list',20)} ${T('acResults')}</h3>
  <label>${T('batchSel')}</label><select name="rbatch"><option value="">${T('resNoBatch')}</option>${batchList().map(b=>opt(b.id,b.name+(b.course?' · '+courseName(b.course):''),r.batch===b.id)).join('')}</select>
  <div class="two"><div><label>${T('examName')}</label><input name="exam" required maxlength="80" value="${esc(r.exam)}"></div><div><label>${T('totalMarks')}</label><input name="total" type="number" min="1" required value="${esc(r.total)}"></div></div>
  <small class="hint">${T('resHint')}</small>
  <div id="rrows">${st.map(u=>`<div class="rrow" data-uid="${esc(u.id)}">${avatar(u,'xs')}<div class="rn"><b>${esc(u.name)}</b>${stChip(u)}</div><input class="mk" type="number" min="0" step="0.5" placeholder="${T('marks')}"><input class="gd" maxlength="4" placeholder="${T('grade')}"></div>`).join('')||`<p class="hint">${r.batch?T('noUsers'):T('resNoBatch')}</p>`}</div>
  ${st.length?`<button class="btn send">${T('pubRes')}</button>`:''}</form>`;
}
function acadV(){
  const body={students:acStudents,batches:acBatches,results:acResults,fees:feeV}[S.sub]();
  return `<div class="chips">${[['students','acStudents'],['batches','acBatches'],['results','acResults'],['fees','acFees']].map(([k,t])=>`<button data-act="sub" data-k="${k}" class="${S.sub===k?'on':''}">${T(t)}</button>`).join('')}</div>${body}`;
}
/* ---------- study tab (student) ---------- */
const resCard=r=>`<div class="rcard"><div><b>${esc(r.exam)}</b><small>${fmt(r.createdAt)}</small></div><div class="rs"><span>${esc(r.marks)}/${esc(r.total)}</span><em>${esc(r.grade||'–')}</em></div></div>`;
const eduV=()=>{
  const a=S.open&&all().find(x=>x.id===S.open);if(a)return detailV(a);
  const m=S.me,b=batchOf(m.batchId),old=m.stage==='old';
  const rs=[...S.results].sort((x,y)=>secs(y)-secs(x));
  const ups=sorted(all()).filter(x=>x.status!=='scheduled'&&['exam','class','result','holiday','material','certificate'].includes(x.type)).slice(0,8);
  return `<section class="edu-h"><span class="pill">${old?'🎓 '+T('oldStudent'):'📘 '+T('currentStudent')}</span><h2>${esc(courseName(m.course)||T('noCourse'))}</h2><p>${b?esc(b.name)+(b.start?' · '+fday(b.start)+(b.end?' → '+fday(b.end):''):''):T('noBatch2')}</p></section>
  ${old?`<div class="note">ℹ️ ${T('oldNote')}</div>`:''}${dueCard()}
  ${m.cert==='ready'?`<div class="note ok">🎓 ${T('certReady')}</div>`:m.cert==='given'?`<div class="note">✅ ${T('certGiven')}</div>`:''}
  <h3 class="sh">${ic('list',18)} ${T('results')}</h3>${rs.length?rs.map(resCard).join(''):`<p class="hint">${T('noResults')}</p>`}
  <h3 class="sh" style="margin-top:16px">${ic('bell',18)} ${T('updatesT')}</h3><div id="feed">${ups.length?ups.map(card).join(''):`<p class="hint">${T('noPosts')}</p>`}</div>`;
};
const typeRow=t=>`<div class="trow" data-tid="${esc(t.id)}"><input class="te" maxlength="4" value="${esc(t.e)}" aria-label="emoji"><input class="ten" placeholder="English" value="${esc(t.en)}"><input class="tbn" placeholder="বাংলা" value="${esc(t.bn)}">
  <input class="tc" type="color" value="${hexOk(t.c)}" aria-label="colour"><select class="tk">${[['plain','kPlain'],['dates','kDates'],['deadline','kDeadline']].map(([v,k])=>`<option value="${v}" ${(t.k||'plain')===v?'selected':''}>${T(k)}</option>`).join('')}</select><button type="button" class="ib dngb" data-act="rmtype" aria-label="remove">✕</button></div>`;
const crow=c=>`<div class="trow crow" data-cid="${esc(c.id)}" style="grid-template-columns:1fr 44px"><input class="cn" value="${esc(c.name)}" placeholder="${T('course')}"><button type="button" class="ib dngb" data-act="rmcourse" aria-label="remove">✕</button></div>`;
const setV=()=>themeBox()+`<form id="set" class="sec"><h3 class="sh">${ic('set',20)} ${T('settings')}</h3><label>${T('cloudName')}</label><input name="c" value="${esc(S.cfg.cloud)}"><label>${T('preset')}</label><input name="p" value="${esc(S.cfg.preset)}">
  <label>${T('workerUrl')}</label><input name="w" type="url" placeholder="https://sctc-push.xxx.workers.dev" value="${esc(S.cfg.workerUrl)}">
  <label>${T('phone')}</label><input name="tel" type="tel" value="${esc(S.cfg.phone)}"><label>${T('gradeScale')}</label><input name="gs" value="${esc(S.cfg.grades||GRADES0)}"><button class="btn">${T('saveForm')}</button></form>
  <form id="courses" class="sec"><h3 class="sh">${ic('cap',20)} ${T('coursesT')}</h3><small class="hint">${T('coursesHint')}</small><div id="crows">${courses().map(crow).join('')}</div><button type="button" class="btn ghost sm" data-act="addcourse">${T('addCourse')}</button><button class="btn">${T('saveForm')}</button></form>
  <div class="sec"><h3 class="sh">${ic('list',20)} ${T('tplSet')}</h3>${tplCards()}<button class="btn ghost sm" data-act="tnew">${T('newTplB')}</button></div>
  <form id="types" class="sec"><h3 class="sh">${ic('list',20)} ${T('typesTitle')}</h3><small class="hint">${T('typesHint')}</small><div id="trows">${getTypes().map(typeRow).join('')}</div>
  <button type="button" class="btn ghost sm" data-act="addtype">${T('addType')}</button><button class="btn">${T('saveForm')}</button><button type="button" class="btn ghost sm" data-act="resettypes">${T('resetTypes')}</button></form>${outBtn()}${verLine()}`;
const idCode=uid=>('SCTC-'+hash(uid).toUpperCase().padStart(6,'0')).slice(0,11);
const idCard=()=>{const m=S.me,stu=m.role==='student',b=batchOf(m.batchId);
  return `<div class="idc"><div class="idh"><img src="logo.png" alt=""><div><b>${APPN}</b><small>Sabuj Computer Training Center</small></div><span>${stu?T('idStudent'):T('idMember')}</span></div>
  <div class="idb">${avatar(m,'idp')}<div class="idi"><h3>${esc(m.name)}</h3>${stu?`<p>${esc(courseName(m.course)||'—')}${b?' · '+esc(b.name):''}</p>`:''}<p>📞 ${esc(m.mobile||'—')}</p><p class="idn">${idCode(S.user.uid)}</p></div></div>${stu?`<div class="idf">${m.stage==='old'?T('stOld'):T('stCur')}</div>`:''}</div>`};
const meV=()=>idCard()+profF(S.me,false)+contact()+`<button class="btn ghost" data-act="shareapp">${ic('share',18)} ${T('shareApp')}</button>`+`<details class="tips"><summary>${T('tipsT')}</summary><p>${T('tipsB')}</p></details>`+themeBox()+outBtn()+verLine();

function render(){
  if(!S.user)return;
  if(!ADMIN&&!S.me)return;
  if(!ADMIN&&S.complete)return completeV();
  bar('green');
  const stu=!ADMIN&&S.me.role==='student';
  const tabs=ADMIN?[['send','send',T('send')],['posts','list',T('posts')],['acad','cap',T('academy')],['users','users',T('users')],['set','set',T('settings')]]:[['home','home',T('home')],...(stu?[['edu','cap',T('study')]]:[]),['jobs','jobs',T('jobs')],['me','user',T('profile')]];
  const body=({send:()=>S.sendMode==='tpl'&&!S.tplEdit&&!S.edit?tplV():composeV(),posts:()=>feedV(false),acad:acadV,users:usersV,set:setV,home:()=>feedV(false),edu:eduV,jobs:()=>feedV(true),me:meV}[S.tab]||(()=>feedV(false)))();
  const n=ADMIN?0:unread();
  app.innerHTML=`<header><img src="logo.png" alt=""><div class="ht"><b>${NAME}</b></div>${langBtn()}</header><div id="net" ${navigator.onLine?'hidden':''}>${T('offBanner')}</div><div id="upd">${updBar()}</div><main>${body}</main>
  <nav>${tabs.map(([k,i,l])=>`<button data-tab="${k}" class="${S.tab===k?'on':''}"><span class="ni">${ic(i,22)}${k==='home'&&n?`<em>${n>99?'99+':n}</em>`:''}</span>${l}</button>`).join('')}</nav>`;
  const f=document.getElementById('send');
  if(f){const a=S.edit||S.draft;
    if(a){if(a.type)f.typ.value=a.type;if(a.audience?.length){const x=a.audience[0];f.aud.value=x.startsWith('u_')?'users':x.startsWith('b_')?'batch':x.startsWith('c_')?'course':x}}
    else if(S.dr){f.ttl.value=S.dr.ttl;f.msg.value=S.dr.msg;if(S.dr.typ)f.typ.value=S.dr.typ;if(S.dr.aud)f.aud.value=S.dr.aud}
    viewSel(f);updPreview(f)}
  if(ADMIN&&S.tab==='posts')loadCounts();
}
function viewSel(f){
  const v=f.aud.value;document.getElementById('pw').hidden=v!=='users';document.getElementById('bx').hidden=v!=='batch';document.getElementById('cx').hidden=v!=='course';
  const k=tyOf(f.typ.value).k||'plain';document.getElementById('hol').hidden=k!=='dates';document.getElementById('jb').hidden=k!=='deadline';
  const r=document.getElementById('rmb');if(r)r.hidden=k==='plain';
}
function loadCounts(){
  for(const a of sorted(S.ann).slice(0,30)){
    if(a.status==='scheduled'||S.rc[a.id]!==undefined)continue;
    S.rc[a.id]=null;
    getCountFromServer(collection(db,'announcements',a.id,'reads')).then(r=>{const c=r.data().count;S.rc[a.id]=c;const e=document.querySelector(`[data-rc="${a.id}"] b`);if(e)e.textContent=c}).catch(()=>{delete S.rc[a.id]});
  }
}

/* ---------- actions ---------- */
function audOf(f){
  const v=f.aud.value,pick=q=>[...f.querySelectorAll(q+':checked')];
  if(v==='course'){const l=pick('.cc');if(!l.length)throw Error(T('errCourse'));return {audience:l.map(c=>'c_'+c.value),al:'📘 '+l.map(c=>courseName(c.value)).join(', ')}}
  if(v==='batch'){const l=pick('.bc2');if(!l.length)throw Error(T('errBatch'));return {audience:l.map(c=>'b_'+c.value),al:'🎓 '+l.map(c=>batchOf(c.value)?.name||'').join(', ')}}
  if(v==='users'){const l=pick('.uc');if(!l.length)throw Error(T('errSel'));if(l.length>40)throw Error(T('errMax40'));return {audience:l.map(c=>'u_'+c.value),al:`${l.length} ${T('ppl')}`}}
  return {audience:[v],al:({student:T('allStudents'),cs:T('curStudents'),os:T('oldStudents'),public:T('allCustomers'),all:T('everyone')})[v]};
}
async function doSend(f){
  try{
    online();
    if(S.tplEdit)return await doTplSave(f,false);
    const old=S.edit||{},base=S.edit||S.draft||{};
    const sch=f.sch?.value?new Date(f.sch.value):null;if(sch&&sch<=new Date())throw Error(T('errFuture'));
    const a=await collect(f,base);a.status=sch?'scheduled':'sent';
    const k=tyOf(a.type).k||'plain',hol=k==='dates',jb=k==='deadline';
    if(sch)a.sendAt=Timestamp.fromDate(sch);else if(old.sendAt)a.sendAt=deleteField();
    let id=old.id;
    if(id){if(old.status==='scheduled'&&!sch)a.createdAt=serverTimestamp();await updateDoc(doc(db,'announcements',id),a)}
    else id=(await addDoc(collection(db,'announcements'),{...a,createdAt:serverTimestamp()})).id;
    let m=sch?T('schedOk'):f.nt.checked?T('sentOk'):T('savedOk');
    if(!sch&&f.nt.checked)await notify(a,id);
    const ref=hol?f.hf.value:jb?f.dl.value:'';
    if(!old.id&&ref&&f.rm?.checked){
      const r=new Date(ref+'T09:00:00');r.setDate(r.getDate()-1);
      if(r>new Date()){await addDoc(collection(db,'announcements'),{...a,title:T('reminder')+': '+a.title,body:(T('tomorrow')+' '+a.body).trim(),pinned:false,push:true,status:'scheduled',sendAt:Timestamp.fromDate(r),createdAt:serverTimestamp()});m+=T('remSet')}
      else m+=T('remLate');
    }
    toast(m);S.edit=null;S.draft=null;S.dr=null;S.tab='posts';S.rc={};render();
  }catch(x){toast(err(x))}
}
async function doFee(f){
  try{
    online();
    const ids=[...f.querySelectorAll('.fc:checked')].map(c=>c.value);
    if(!ids.length)throw Error(T('selStu'));if(ids.length>40)throw Error(T('errMax40'));
    const items=[];
    await Promise.all(ids.map(async id=>{
      const u=S.users.find(x=>x.id===id);
      const a={title:T('feeTitle'),body:f.msg.value.replace(/\{name\}/g,u.name).replace(/\{due\}/g,u.due),type:'fee',sub:tlab('fee'),audience:['u_'+id],pinned:false,status:'sent',push:true,cover:'',links:[],files:[],createdAt:serverTimestamp()};
      const r=await addDoc(collection(db,'users',id,'inbox'),a);items.push(item(a,r.id));
    }));
    await post({items});toast(T('remSent')+' ('+ids.length+')');
  }catch(x){toast(err(x))}
}
async function doProf(f){
  try{
    online();
    let photo=S.me?.photo||'';if(f.ph.files[0])photo=await up(f.ph.files[0]);
    const d={name:f.n.value.trim(),mobile:f.m.value.trim(),village:f.v.value.trim(),photo};
    if(!S.me){d.role=f.r.value;d.email=S.user.email||'';d.createdAt=serverTimestamp()}
    if(f.crs&&!f.crs.disabled&&f.crs.value&&(S.me?S.me.role:d.role)==='student')d.course=f.crs.value;
    await setDoc(doc(db,'users',S.user.uid),d,{merge:true});toast(T('savedOk'));
    if(!S.me){enter(S.user)}else{S.me={...S.me,...d};S.complete=incomplete(S.me);render()}
  }catch(x){toast(err(x))}
}
async function doAuth(f){
  try{
    if(mode==='up'){S.signup={n:f.n.value.trim(),r:S.roleSel};await createUserWithEmailAndPassword(auth,f.e.value.trim(),f.p.value)}
    else await signInWithEmailAndPassword(auth,f.e.value.trim(),f.p.value);
    loadV(T('signingIn'));
  }catch(x){S.signup=null;toast(err(x))}
}
async function saveCfg(patch){online();await setDoc(doc(db,'settings','main'),patch,{merge:true});S.cfg={...S.cfg,...patch}}
async function doTypes(f){
  try{
    const types=[...f.querySelectorAll('.trow')].map(r=>({id:r.dataset.tid,e:r.querySelector('.te').value.trim()||'📌',en:r.querySelector('.ten').value.trim(),bn:r.querySelector('.tbn').value.trim(),c:hexOk(r.querySelector('.tc').value),k:r.querySelector('.tk').value})).filter(t=>t.en||t.bn);
    if(!types.length)throw Error(T('typeNeed'));
    await saveCfg({types});toast(T('savedOk'));render();
  }catch(x){toast(err(x))}
}
function rerender(){if(!S.user)authV();else if(!S.me&&!ADMIN)profileV();else render()}
const ACT={
  lang(){lang=lang==='bn'?'en':'bn';jset('lang',lang);document.documentElement.lang=lang;rerender()},
  setlang(_,el){lang=el.dataset.v;jset('lang',lang);document.documentElement.lang=lang;rerender()},
  theme(_,el){theme=el.dataset.v;jset('theme',theme);applyTheme();render()},
  doupdate(){return doUpdate()},
  mode(_,el){mode=el.dataset.m;authV()},
  role(_,el){S.roleSel=el.dataset.r;const f=document.getElementById('auth'),v=[f.n.value,f.e.value];authV();const g=document.getElementById('auth');g.n.value=v[0];g.e.value=v[1]},
  eye(_,el){const i=el.parentNode.querySelector('input');i.type=i.type==='password'?'text':'password'},
  async fg(){const e=document.querySelector('[name=e]')?.value.trim();if(!e)return toast(T('enterEmail'));try{await sendPasswordResetEmail(auth,e);toast(T('resetSent'))}catch(x){toast(err(x))}},
  async gg(){
    try{
      if(native){const r=await googleNative();await signInWithCredential(auth,GoogleAuthProvider.credential(r.credential?.idToken))}
      else await signInWithPopup(auth,new GoogleAuthProvider());
      loadV(T('signingIn'));
    }catch(x){const m=String(x?.message||x);toast(/(^|\D)10(\D|$)|DEVELOPER/i.test(m)?T('googleHint'):m.slice(0,160),7000)}
  },
  async logout(){
    if(native&&!ADMIN&&S.user&&S.me){for(const t of new Set([...topicsOf(S.me),...jget('tp','[]'),'student','public','cs','os']))try{await FirebaseMessaging.unsubscribeFromTopic({topic:t})}catch{}
      try{await updateDoc(doc(db,'users',S.user.uid),{fcm:deleteField()})}catch{}}
    clr();S.me=null;S.ann=[];S.inbox=[];S.users=[];S.tpls=[];S.dr=null;S.tplEdit=null;S.results=[];S.open=null;S.edit=null;S.complete=false;S.ready={};S.rc={};S.tab=HOME;jset('tp','[]');
    try{if(native)await FirebaseAuthentication.signOut()}catch{}
    await signOut(auth);
  },
  back(){goBack()},cancel(){if(S.tplEdit)S.sendMode='tpl';S.edit=null;S.draft=null;S.tplEdit=null;render()},flt(_,el){S.f=el.dataset.k;render()},
  save(id){const s=saved(),on=!s.includes(id);jset('saved',on?[...s,id]:s.filter(x=>x!==id));
    if(S.f==='__saved'&&!on&&!S.open)return render();
    document.querySelectorAll('[data-act="save"]').forEach(b=>{if(b.closest('[data-id]')?.dataset.id===id)b.classList.toggle('on',on)})},
  async shareapp(){const url=REPO?`https://github.com/${REPO}/releases/tag/student`:location.href;try{if(navigator.share)await navigator.share({title:APPN,text:T('shareTxt'),url});else{await navigator.clipboard.writeText(url);toast(T('copied'))}}catch{}},
  async share(id){const a=all().find(x=>x.id===id);if(!a)return;const txt=`${a.title}\n${a.body||''}`.slice(0,500);
    try{if(navigator.share)await navigator.share({title:a.title,text:txt});else{await navigator.clipboard.writeText(txt);toast(T('copied'))}}catch{}},
  readall(){jset('seen',[...new Set([...seen(),...all().filter(a=>a.status!=='scheduled').map(a=>a.id)])].slice(-400));render()},
  async notifreq(){try{await FirebaseMessaging.requestPermissions();await checkNotif();if(S.notifOff)toast(T('notifHow'),6000);else{reg(S.me);render()}}catch{}},
  dup(id){const a=S.ann.find(x=>x.id===id);S.draft={...a,sendAt:undefined,status:'sent',pinned:false};S.edit=null;S.tab='send';render();scrollTo(0,0)},
  smode(_,el){S.sendMode=el.dataset.k;S.edit=null;S.draft=null;S.tplEdit=null;render()},
  tuse(id){const t=tplList().find(x=>x.id===id);if(!t)return;S.draft={...t};S.edit=null;S.tplEdit=null;S.sendMode='new';S.tab='send';render();scrollTo(0,0)},
  tedit(id){const t=tplList().find(x=>x.id===id);if(!t)return;S.tplEdit=id;S.draft={...t};S.edit=null;S.tab='send';render();scrollTo(0,0)},
  tnew(){S.tplEdit='new';S.draft={};S.edit=null;S.tab='send';render();scrollTo(0,0)},
  async tdel(id){if(!confirm(T('tplDelC')))return;await saveTpls(tplList().filter(x=>x.id!==id));render()},
  async tsend(id){
    const t=tplList().find(x=>x.id===id);if(!t)return;
    if(!t.audience?.length)return toast(T('tplNoAud'),5000);
    if(!confirm(T('tplSendC').replace('{n}',t.name).replace('{a}',t.al||'')))return;online();
    const a={title:t.title,body:t.body,type:t.type,sub:tlab(t.type),audience:t.audience,al:t.al||'',pinned:!!t.pinned,push:true,cover:t.cover||'',from:'',to:'',org:t.org||'',deadline:'',status:'sent',links:t.links||[],files:t.files||[]};
    const r=await addDoc(collection(db,'announcements'),{...a,createdAt:serverTimestamp()});await notify(a,r.id);S.rc={};toast(T('sentOk'));
  },
  async savetpl(_,el){const f=el.closest('form');if(!f.checkValidity())return f.reportValidity();online();await doTplSave(f,true)},
  tpl(_,el){const t=TPL[+el.dataset.i],f=document.getElementById('send');f.ttl.value=t[lang][0];f.msg.value=t[lang][1];if(getTypes().some(x=>x.id===t.ty))f.typ.value=t.ty;viewSel(f)},
  addlink(){document.getElementById('lks').insertAdjacentHTML('beforeend',linkRow())},
  addtype(){document.getElementById('trows').insertAdjacentHTML('beforeend',typeRow({id:'c'+Date.now().toString(36),e:'📌',en:'',bn:'',c:'#0b6b2b',k:'plain'}))},
  rmtype(_,el){el.closest('.trow').remove()},
  async resettypes(){if(!confirm(T('resetConfirm')))return;online();await setDoc(doc(db,'settings','main'),{types:deleteField()},{merge:true});const {types,...rest}=S.cfg;S.cfg=rest;toast(T('savedOk'));render()},
  edit(id){S.edit=S.ann.find(x=>x.id===id);S.tab='send';render();scrollTo(0,0)},
  async resend(id){try{online();await notify(S.ann.find(x=>x.id===id),id);toast(T('sentOk'))}catch(x){toast(err(x))}},
  pin(id){const a=S.ann.find(x=>x.id===id);return updateDoc(doc(db,'announcements',id),{pinned:!a.pinned})},
  del(id){if(confirm(T('delConfirm')))return deleteDoc(doc(db,'announcements',id))},
  sub(_,el){S.sub=el.dataset.k;render()},afstage(_,el){S.af.stage=el.dataset.k;render()},ff(_,el){S.ff=el.dataset.k;render()},
  async ssave(id,el){
    online();const c=el.closest('[data-uid]'),u=S.users.find(x=>x.id===id);
    const p={course:c.querySelector('.f-course').value,batchId:c.querySelector('.f-batch').value,stage:c.querySelector('.f-stage').value,cert:c.querySelector('.f-cert').value,due:Math.max(0,Math.round(+c.querySelector('.f-due').value||0))};
    await updateDoc(doc(db,'users',id),p);const d=diffTopics(id,u,{...u,...p});if(d)await pushTopics([d]);toast(T('savedOk'));
  },
  async bsave(id,el){const c=el.closest('[data-bid]');await saveBatches(batchList().map(b=>b.id===id?{...b,name:c.querySelector('.bn').value.trim()||b.name,course:c.querySelector('.bc').value,start:c.querySelector('.bs').value,end:c.querySelector('.be').value}:b));toast(T('savedOk'));render()},
  async bdone(id){
    const b=batchOf(id);if(!confirm(T('bdoneC').replace('{n}',b.name)))return;online();
    const st=S.users.filter(u=>u.role==='student'&&u.batchId===id&&u.stage!=='old');
    const wb=writeBatch(db);st.forEach(u=>wb.update(doc(db,'users',u.id),{stage:'old'}));await wb.commit();
    await saveBatches(batchList().map(x=>x.id===id?{...x,done:true}:x));
    const d=st.map(u=>diffTopics(u.id,u,{...u,stage:'old'})).filter(Boolean);if(d.length)await pushTopics(d);
    toast(`${st.length} ${T('moved')}`);render();
  },
  async bcert(id){
    const b=batchOf(id);if(!confirm(T('bcertC').replace('{n}',b.name)))return;online();
    const wb=writeBatch(db);S.users.filter(u=>u.role==='student'&&u.batchId===id).forEach(u=>wb.update(doc(db,'users',u.id),{cert:'ready'}));await wb.commit();
    const a={title:T('certTitle'),body:T('certBody').replace('{n}',b.name),type:'certificate',sub:tlab('certificate'),audience:['b_'+id],al:'🎓 '+b.name,pinned:false,push:true,cover:'',from:'',to:'',org:'',deadline:'',status:'sent',links:[],files:[]};
    const r=await addDoc(collection(db,'announcements'),{...a,createdAt:serverTimestamp()});await notify(a,r.id);toast(T('sentOk'));S.rc={};render();
  },
  async bdel(id){if(S.users.some(u=>u.batchId===id))return toast(T('bdelBlock'),5000);if(!confirm(T('delConfirm')))return;await saveBatches(batchList().filter(x=>x.id!==id));render()},
  addcourse(){document.getElementById('crows').insertAdjacentHTML('beforeend',crow({id:'k'+Date.now().toString(36),name:''}))},
  rmcourse(_,el){el.closest('.crow').remove()},
  async reset(id){const u=S.users.find(x=>x.id===id);try{await sendPasswordResetEmail(auth,u.email);toast(T('resetTo')+u.email)}catch(x){toast(err(x))}},
  async rmuser(id){
    online();const u=S.users.find(x=>x.id===id);if(!confirm(T('delAccConfirm').replace('{n}',u.name)))return;
    await post({action:'deleteUser',uid:id});
    for(const sub of ['inbox','results'])for(const d of (await getDocs(collection(db,'users',id,sub))).docs)await deleteDoc(d.ref);
    await deleteDoc(doc(db,'users',id));toast(T('deleted'));
  }
};
app.onclick=async e=>{
  if(e.target.closest('a'))return;
  const tb=e.target.closest('[data-tab]');
  if(tb){S.tab=tb.dataset.tab;S.open=null;S.edit=null;S.draft=null;S.tplEdit=null;S.f='';if(S.tab==='posts')S.rc={};render();return scrollTo(0,0)}
  const el=e.target.closest('[data-act]');
  if(el){const h=el.closest('[data-id],[data-uid],[data-bid]'),a=el.dataset.act,go=()=>ACT[a](h?.dataset.id||h?.dataset.uid||h?.dataset.bid||el.dataset.id,el);try{await (LONG.has(a)?run(el,go):go())}catch(x){toast(err(x))}return}
  const c=e.target.closest('[data-open]');if(c&&!ADMIN){openPost(c.dataset.id);render();scrollTo(0,0)}
};
async function doSet(f){try{await saveCfg({cloud:f.c.value.trim(),preset:f.p.value.trim(),workerUrl:f.w.value.trim(),phone:f.tel.value.trim(),grades:f.gs.value.trim()||GRADES0});toast(T('savedOk'))}catch(x){toast(err(x))}}
const saveBatches=b=>saveCfg({batches:b});
async function doNewBatch(f){try{await saveBatches([...batchList(),{id:'b'+Date.now().toString(36),name:f.bn.value.trim(),course:f.bc.value,start:f.bs.value,end:f.be.value,done:false}]);toast(T('savedOk'));render()}catch(x){toast(err(x))}}
async function doCourses(f){
  try{
    const l=[...f.querySelectorAll('.crow')].map(r=>({id:r.dataset.cid,name:r.querySelector('.cn').value.trim()})).filter(c=>c.name);
    if(!l.length)throw Error(T('typeNeed'));await saveCfg({courses:l});toast(T('savedOk'));render();
  }catch(x){toast(err(x))}
}
async function doResults(f){
  try{
    online();
    const batchId=f.rbatch.value,exam=f.exam.value.trim(),total=+f.total.value;
    if(!batchId)throw Error(T('resNoBatch'));if(!exam||!(total>0))throw Error(T('errExam'));
    const rows=[...f.querySelectorAll('.rrow')].map(r=>({id:r.dataset.uid,mk:r.querySelector('.mk').value,gd:r.querySelector('.gd').value.trim()})).filter(x=>x.mk!=='');
    if(!rows.length)throw Error(T('errNoRows'));
    if(rows.some(x=>+x.mk>total||+x.mk<0))throw Error(T('errMarks'));
    const b=batchOf(batchId),rid='r'+hash(exam+batchId);
    for(let i=0;i<rows.length;i+=20){
      const items=[];
      await Promise.all(rows.slice(i,i+20).map(async x=>{
        const u=S.users.find(y=>y.id===x.id),marks=+x.mk,grade=x.gd||gradeOf(marks,total);
        await setDoc(doc(db,'users',x.id,'results',rid),{exam,marks,total,grade,batchId,course:b?.course||u.course||'',createdAt:serverTimestamp()});
        const a={title:exam,body:`${T('marks')}: ${marks}/${total} · ${T('grade')}: ${grade}`,type:'result',sub:tlab('result'),audience:['u_'+x.id],pinned:false,status:'sent',push:true,cover:'',links:[],files:[],createdAt:serverTimestamp()};
        const r=await addDoc(collection(db,'users',x.id,'inbox'),a);items.push(item(a,r.id));
      }));
      await post({items});
    }
    toast(`${T('resSent')} (${rows.length})`);S.rs={batch:batchId,exam:'',total};render();
  }catch(x){toast(err(x))}
}
const FORMS={auth:doAuth,send:doSend,prof:doProf,fee:doFee,types:doTypes,set:doSet,newbatch:doNewBatch,courses:doCourses,results:doResults};
app.onsubmit=e=>{e.preventDefault();const f=e.target,h=FORMS[f.id];if(!h)return;
  run(e.submitter||f.querySelector('button:not([type="button"])'),()=>h(f))};

app.onchange=async e=>{const el=e.target;
  if(el.form?.id==='send')formTouched(el.form);
  if(el.name==='rbatch'){const f=el.form;S.rs={batch:el.value,exam:f.exam.value,total:f.total.value};return render()}
  if(el.dataset.af){S.af[el.dataset.af]=el.value;return render()}
  if(el.name==='aud'||el.name==='typ')viewSel(el.form);
  if(el.name==='r'&&el.form?.id==='prof'){const s=el.value==='student',f=el.form;f.querySelector('.n-stu').hidden=!s;f.querySelector('.n-cus').hidden=s;f.v.required=s;f.querySelector('.crs').hidden=!s;f.crs.required=s;f.querySelector('.vl').textContent=s?T('village'):T('address')}
  if(el.dataset.role){try{const id=el.closest('[data-uid]').dataset.uid,u=S.users.find(x=>x.id===id);online();await updateDoc(doc(db,'users',id),{role:el.value});const d=u&&diffTopics(id,u,{...u,role:el.value});if(d)await pushTopics([d]);toast(T('updated'))}catch(x){toast(err(x))}}};
app.oninput=e=>{const el=e.target;
  if(el.form?.id==='send')formTouched(el.form);
  if(el.classList.contains('gd')){el.dataset.man=el.value?'1':''}
  if(el.classList.contains('mk')||el.name==='total'){const f=el.closest('form'),tot=+f.total.value;f.querySelectorAll('.rrow').forEach(r=>{const mk=r.querySelector('.mk'),gd=r.querySelector('.gd');if(!gd.dataset.man)gd.value=mk.value===''||!(tot>0)?'':gradeOf(+mk.value,tot)});return}
  if(!el.dataset.q)return;const v=el.value.toLowerCase();
  document.querySelectorAll(`#${el.dataset.q} [data-item]`).forEach(n=>{n.hidden=!n.textContent.toLowerCase().includes(v)})};

app.onkeydown=e=>{if(e.key==='Enter'&&e.target.tagName==='INPUT'&&e.target.form?.id==='send')e.preventDefault()}; // Enter must never send a notification by accident

/* ---------- boot ---------- */
function start(){
  clr();S.ready={};const u=S.user.uid,ud=[];
  const ls=(q,k)=>onSnapshot(q,s=>{S[k]=s.docs.map(d=>({id:d.id,...d.data()}));S.ready[k]=true;soft()},x=>{console.warn(x);S.ready[k]=true;soft()});
  if(ADMIN){ud.push(ls(collection(db,'announcements'),'ann'),ls(collection(db,'users'),'users'),onSnapshot(doc(db,'settings','templates'),t=>{S.tpls=t.data()?.list||[];soft()},()=>{}))}
  else{
    ud.push(onSnapshot(doc(db,'users',u),s=>{const m=s.data();if(!m)return;const ch=S.me&&tkey(S.me)!==tkey(m);S.me=m;ch?start():soft()}),
      ls(query(collection(db,'announcements'),where('audience','array-contains-any',topicsOf(S.me))),'ann'),
      ls(collection(db,'users',u,'inbox'),'inbox'),
      ls(collection(db,'users',u,'results'),'results'));
    reg(S.me).then(checkNotif).then(soft);
  }
  ud.push(onSnapshot(doc(db,'settings','main'),s=>{S.cfg=s.data()||{};soft()}));
  S.un=ud;render();chk();
  if(S.pending){const id=S.pending;S.pending=null;handleOpen(id)}
}
async function enter(u){
  clr();S.user=u;if(!u)return authV();
  loadV(T('signingIn'));
  try{
    try{S.cfg=(await getDoc(doc(db,'settings','main'))).data()||{}}catch{}
    if(ADMIN){const a=await getDoc(doc(db,'admins',u.uid));if(!a.exists()){toast(T('notAdmin'));return signOut(auth)}}
    else{
      let p=await getDoc(doc(db,'users',u.uid));
      if(!p.exists()){
        if(!S.signup)return profileV();
        await setDoc(doc(db,'users',u.uid),{name:S.signup.n,role:S.signup.r,email:u.email||'',mobile:'',village:'',photo:'',createdAt:serverTimestamp()});S.signup=null;
        p=await getDoc(doc(db,'users',u.uid));
      }
      S.me=p.data();S.complete=incomplete(S.me);
    }
    start();
  }catch(x){app.innerHTML=`<p class="empty">${T('offline')}<br>${esc(err(x))}</p>`}
}
onAuthStateChanged(auth,enter);
